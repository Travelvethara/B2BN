<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
	
});

Auth::routes();

Route::get('/handlelogin', 'Auth\LoginController@credentials')->name('handlelogin');
Route::post('/agency', 'Agency\AgencyController@agencystore')->name('agency.agencystore');

Route::get('/home', 'HomeController@index')->name('home');
Route::post('/agency', 'Agency\AgencyController@agencystore')->name('agency.agencystore');
Route::post('/agencyupdate', 'Agency\AgencyController@agencyupdate')->name('agency.agencyupdate');
Route::get('/viewagency', 'Agency\AgencyController@viewagency')->name('agency.viewagency');
Route::post('/updateagency', 'Agency\AgencyController@updateagency')->name('agency.updateagency');


Route::post('/agencymanager', 'Agency\AgencyController@agencymanager')->name('agency.agencymanager');
Route::post('/agencyregister', 'Auth\RegisterController@agencyregister')->name('agency.agencyregister');

Route::get('/agency', 'Agency\AgencyController@index')->name('agency');

Route::get('/agencylist','Agency\AgencylistController@index');
Route::get('/agencylistLoadMoreAjax','Agency\AgencylistController@agencyListLoadMore');




//role

Route::get('/role', 'Role\RoleController@index')->name('role');

Route::get('/rolelist', 'Role\RoleController@rolelist')->name('rolelist');

Route::post('/rolei', 'Role\RoleController@roleinsert')->name('role.roleinsert');

Route::post('/roleu', 'Role\RoleController@roleupdate')->name('role.roleupdate');

Route::post('/roled', 'Role\RoleController@RoleDelete')->name('role.RoleDelete');


//profile

Route::get('/profile', 'Profile\ProfileController@index')->name('profile');


Route::post('/profileupdate', 'Profile\ProfileController@profileupdate')->name('profile.profileupdate');


//User

Route::get('/user', 'User\UserController@index');

Route::post('/user', 'User\UserController@userinsert')->name('userinsert');

Route::get('/userupdate', 'User\UserController@userupdate');

Route::post('/userupdate', 'User\UserController@userupdatemodify')->name('userupdate');

Route::get('/userlist','User\UserController@userlist');

Route::post('/userdelete', 'User\UserController@userdelete')->name('userdelete');