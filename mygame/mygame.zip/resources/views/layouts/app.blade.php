        @include('./includes.header')
<div class="m-grid__item m-grid__item--fluid m-grid m-grid--ver-desktop m-grid--desktop m-body">		
        @include('includes.menu')
           @yield('content')
		   </div>
        @include('./includes.footer')