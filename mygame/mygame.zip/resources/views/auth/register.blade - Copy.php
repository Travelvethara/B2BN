<!DOCTYPE html>
<!-- 
Template Name: Metronic - Responsive Admin Dashboard Template build with Twitter Bootstrap 4
Author: KeenThemes
Website: http://www.keenthemes.com/
Contact: support@keenthemes.com
Follow: www.twitter.com/keenthemes
Dribbble: www.dribbble.com/keenthemes
Like: www.facebook.com/keenthemes
Purchase: http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes
Renew Support: http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes
License: You must have a valid license purchased only from themeforest(the above link) in order to legally use the theme for your project.
-->
<html lang="en" >
	<!-- begin::Head -->
	<head>
		<meta charset="utf-8" />
		<title>
			Metronic | Login Page - 3
		</title>
		<meta name="description" content="Latest updates and statistic charts">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!--begin::Web font -->
		<script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.16/webfont.js"></script>
		<script>
          WebFont.load({
            google: {"families":["Poppins:300,400,500,600,700","Roboto:300,400,500,600,700"]},
            active: function() {
                sessionStorage.fonts = true;
            }
          });
		</script>
		<!--end::Web font -->
        <!--begin::Base Styles -->
			<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">
		<link href="public/css/fullcalendar.bundle.css" rel="stylesheet" type="text/css" />
		<!--end::Page Vendors -->
		<link href="public/css/vendors.bundle.css" rel="stylesheet" type="text/css" />
		<link href="public/css/style.bundle.css" rel="stylesheet" type="text/css" />
		<link href=" public/css/custom.css" rel="stylesheet" type="text/css" />
		<!--end::Base Styles -->
		<link rel="shortcut icon" href="assets/demo/default/media/img/logo/favicon.ico" />
	</head>
	<!-- end::Head -->
    <!-- end::Body -->
	<body  class="m--skin- m-header--fixed m-header--fixed-mobile m-aside-left--enabled m-aside-left--skin-dark m-aside-left--offcanvas m-footer--push m-aside--offcanvas-default"  >
		<!-- begin:: Page -->
		<div class="m-grid__item m-grid__item--fluid m-wrapper">
					<!-- BEGIN: Subheader -->
					<div class="m-subheader ">
						<div class="d-flex align-items-center">
							<div class="mr-auto">
								<h3 class="m-subheader__title ">
									Create Agency
								</h3>
							</div>
						</div>
					</div>
					<!-- END: Subheader -->
					<div class="m-content">
						<!--Begin::Section-->
						<div class="row">
							<ul class="nav nav-tabs  m-tabs-line m-tabs-line--primary" role="tablist">
											<li class="nav-item m-tabs__item">
												<a class="nav-link m-tabs__link" data-toggle="tab" href="#m_tabs_6_1" role="tab" aria-selected="false">
													Agency Information
												</a>
											</li>

										</ul>
						</div>
						<form action="{{route('agency.agencyregister')}}" method="post">
                        <div class="tab-content">
						
						     
							 <input type="hidden" name="_token" value="<?php echo @csrf_token(); ?>">
											<div class="tab-pane active" id="m_tabs_6_1" role="tabpanel">
											
												<div class="m-portlet m-portlet-padding agency-info-tab">
													<div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="text" name="name" class="form-control m-input m-input--square"  placeholder="Name" <?php if (isset($agency->name) && !empty($agency->name)){ ?> value="{{ $agency->name}}" <?php }else{ ?> value="{{ old('name') }}" <?php } ?>>
																		<span class="error-message">   @if ($errors->has('name'))
																			  {{ $errors->first('name') }}
																			@endif    </span>
															</div>
														</div>
														<div class="col-md-6 ">
															<div class="form-group m-form__group">
																<input type="email" name="email" class="form-control m-input m-input--square"  aria-describedby="emailHelp" placeholder="Email" <?php if (isset($agency->email) && !empty($agency->email)){ ?> value="{{ $agency->email }}" <?php } else{ ?> value="{{ old('email') }}" <?php } ?>>
                    	<span class="error-message">  @if ($errors->has('email'))
                       						  {{ $errors->first('email') }}
                       							 @endif </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="text" name="phone" id="phone" class="form-control m-input m-input--square" i placeholder="Phone" <?php if (isset($agency->phone) && !empty($agency->phone)){?> value="{{ $agency->phone }}" <?php }else{ ?>value="{{old('phone')}}"<?php } ?>>
                    						<span class="error-message">  @if ($errors->has('phone'))
                       						  {{ $errors->first('phone') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="text" name="mobile" id="mobile" class="form-control m-input m-input--square"  placeholder="Mobile"  <?php if (isset($agency->mobile) && !empty($agency->mobile)){?> value="{{ $agency->mobile }}" <?php }else{ ?>value="{{old('mobile')}}"<?php } ?>>
                    							<span class="error-message">  @if ($errors->has('mobile'))
                       						  {{ $errors->first('mobile') }}
                       							 @endif </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="text" name="whatsapp" id="whatsapp" class="form-control m-input m-input--square"  placeholder="whatsapp" <?php if (isset($agency->whatapp) && !empty($agency->whatsapp)){?> value="{{ $agency->whatsapp }}" <?php }else{ ?>value="{{old('whatsapp')}}"<?php } ?>>
                    							<span class="error-message">  @if ($errors->has('whatsapp'))
                       						  {{ $errors->first('whatsapp') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															
														</div>
												   </div>
												    <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="password" name="password" class="form-control m-input m-input--square" placeholder="Password" >
                    			<span class="error-message"> @if ($errors->has('password'))
                       						  {{ $errors->first('password') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="password" name="password_confirmation" class="form-control m-input m-input--square"  placeholder="Confirm Password">
															</div>
														</div>
												   </div>
												
												
											</div>
											
												<div class="m-portlet m-portlet-padding agency-info-tab">
													<div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="text" class="form-control m-input m-input--square"  name="aname"  placeholder="Agency Name"<?php if (isset($agency->aname) && !empty($agency->aname)){?> value="{{ $agency->aname }}" <?php }else{ ?>value="{{old('aname')}}"<?php } ?> >
                            <span class="error-message">  @if ($errors->has('aname'))
                       						  {{ $errors->first('aname') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="email" class="form-control m-input m-input--square" name="aemail" aria-describedby="emailHelp" placeholder="Email" <?php if (isset($agency->aemail) && !empty($agency->aemail)){?> value="{{ $agency->aemail }}" <?php }else{ ?>value="{{old('aemail')}}"<?php } ?>>
                    <span class="error-message">  @if ($errors->has('aemail'))
                       						  {{ $errors->first('aemail') }}
                       							 @endif </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="text" class="form-control m-input m-input--square"  name="address1" placeholder="Address Line 1"<?php if (isset($agency->address1) && !empty($agency->address1)){?> value="{{ $agency->address1 }}" <?php }else{ ?>value="{{old('address1')}}"<?php } ?>>
                             <span class="error-message">  @if ($errors->has('address1'))
                       						  {{ $errors->first('address1') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="text" class="form-control m-input m-input--square" name="address2" placeholder="Address Line 2"<?php if (isset($agency->address2) && !empty($agency->address2)){?> value="{{ $agency->address2 }}" <?php }else{ ?>value="{{old('address2')}}"<?php } ?>>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="text" class="form-control m-input m-input--square"  name="country"  placeholder="Country" <?php if (isset($agency->country) && !empty($agency->country)){?> value="{{ $agency->country }}" <?php }else{ ?>value="{{old('country')}}"<?php } ?>>
                             <span class="error-message">  @if ($errors->has('country'))
                       						  {{ $errors->first('country') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="text" class="form-control m-input m-input--square" name="city"  placeholder="City" <?php if (isset($agency->city) && !empty($agency->city)){?> value="{{ $agency->city }}" <?php }else{ ?>value="{{old('city')}}"<?php } ?>>
                               <span class="error-message">  @if ($errors->has('city'))
                       						  {{ $errors->first('city') }}
                       							 @endif </span>
															</div>
														</div>
												   </div>
												    <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="text" class="form-control m-input m-input--square"  name="zip" id="zip" placeholder="Zip / Postal Code"  <?php if (isset($agency->zip) && !empty($agency->zip)){?> value="{{ $agency->zip }}" <?php }else{ ?>value="{{old('zip')}}"<?php } ?>>
                             <span class="error-message">  @if ($errors->has('zip'))
                       						  {{ $errors->first('zip') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="text" class="form-control m-input m-input--square" name="amobile" id="mobile1"  placeholder="Mobile" <?php if (isset($agency->amobile) && !empty($agency->amobile)){?> value="{{ $agency->amobile }}" <?php }else{ ?>value="{{old('amobile')}}"<?php } ?>>
                            <span class="error-message">  @if ($errors->has('amobile'))
                       						  {{ $errors->first('amobile') }}
                       							 @endif </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="text" class="form-control m-input m-input--square"  name="aphone" id="phone1"  placeholder="phone" <?php if (isset($agency->aphone) && !empty($agency->aphone)){?> value="{{ $agency->aphone }}" <?php }else{ ?>value="{{old('aphone')}}"<?php } ?>>
                              <span class="error-message">  @if ($errors->has('aphone'))
                       						  {{ $errors->first('aphone') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="text" class="form-control m-input m-input--square"   name="awhatsapp" id="whatsapp1" placeholder="Whatsapp" <?php if (isset($agency->awhatsapp) && !empty($agency->awhatsapp)){?> value="{{ $agency->awhatsapp }}" <?php }else{ ?>value="{{old('awhatsapp')}}"<?php } ?>>
                                <span class="error-message">  @if ($errors->has('awhatsapp'))
                       						  {{ $errors->first('awhatsapp') }}
                       							 @endif </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="text" class="form-control m-input m-input--square"  name="skype" id="skype" placeholder="Skype" <?php if (isset($agency->skype) && !empty($agency->skype)){?> value="{{ $agency->skype }}" <?php }else{ ?>value="{{old('skype')}}"<?php } ?>>
                             <span class="error-message">  @if ($errors->has('skype'))
                       						  {{ $errors->first('skype') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="text" class="form-control m-input m-input--square"  name="website" placeholder="Website"<?php if (isset($agency->website) && !empty($agency->website)){?> value="{{ $agency->website }}" <?php }else{ ?>value="{{old('website')}}"<?php } ?>>
                               <span class="error-message">  @if ($errors->has('website'))
                       						  {{ $errors->first('website') }}
                       							 @endif </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
																<input type="text" class="form-control m-input m-input--square" name="register_number"  id="register_number"  placeholder="Company Registration number" <?php if (isset($agency->register_number) && !empty($agency->register_number)){?> value="{{ $agency->register_number }}" <?php }else{ ?>value="{{old('register_number')}}"<?php } ?>>
                               <span class="error-message">  @if ($errors->has('register_number'))
                       						  {{ $errors->first('register_number') }}
                       							 @endif </span>
															</div>
														</div>
														
												   </div>
												 
												    <div class="row">
														<div class="col-md-6">
															<button type="submit" class="btn btn-primary">Create Agency</button>
														</div>
													</div>
											    </div>
											</div>
											
							</div>
						<!--End::Section-->
                     </form>
						
						<!--End::Section-->
					</div>
				</div>
			</div>
		<!-- end:: Page -->
    	<!--begin::Base Scripts -->
		<script src="public/js/vendors.bundle.js" type="text/javascript"></script>
		<script src="public/js/scripts.bundle.js" type="text/javascript"></script>
		<!--end::Base Scripts -->   
        <!--begin::Page Snippets -->
		<script src="public/js/login.js" type="text/javascript"></script>
		<!--end::Page Snippets -->
	</body>
	<!-- end::Body -->
</html>
