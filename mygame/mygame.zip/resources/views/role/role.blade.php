@extends('layouts.app')

@section('content')
<?php 
$route = 'role.roleinsert';
if (isset($rolelist) && !empty($rolelist)){ $route = 'role.roleupdate'; }
?>

<!-- END: Left Aside -->
				<div class="m-grid__item m-grid__item--fluid m-wrapper">
					<!-- BEGIN: Subheader -->
					<div class="m-subheader ">
						<div class="d-flex align-items-center">
							<div class="mr-auto">
								<h3 class="m-subheader__title ">
									
                                <?php if (isset($_GET['id']) && !empty($_GET['id'])){ ?> 
								Update Role
								<?php }else{?>
								Create Role
                                <?php } ?>
								</h3>
							</div>
						</div>
					</div>
					<!-- END: Subheader -->
					<div class="m-content user-role">
					<form action="{{route($route)}}" method="post">
                    <input type="hidden" name="_token" value="<?php echo @csrf_token(); ?>">
						<div class="m-portlet m-portlet-padding agency-info-tab">
						<div class="role-name-agency">
							<div class="row positionrelative user-role-agen-block">
								<div class="col-md-6">
									<div class="form-group m-form__group">
                                    <label>Role Name</label>
										<input type="text" class="form-control m-input m-input--square" placeholder="Role Name" name="role_name" <?php if (isset($rolelist->role_name) && !empty($rolelist->role_name)){?> value="{{ $rolelist->role_name }}" <?php }else{ ?> value="{{old('role_name')}}"<?php } ?>>
                                        <span class="error-message">   
                                              @if ($errors->has('role_name'))
                       	                       {{ $errors->first('role_name') }}
                                                 @endif    
                                         </span>
									</div>
								</div>
								<div class="offset-md-6 agencycheck">
									<label class="m-checkbox">
											<input type="checkbox" id="agency_create_user" name="agency_create_user" <?php if (isset($rolelist->agency_create_user) && !empty($rolelist->agency_create_user)){?> checked="checked" <?php }else{ ?> {{ old('agency_create_user') ? 'checked' : '' }} <?php } ?>> Agency can create user on this role.
											<span></span>
									</label>
								</div>
							</div>
							<div class="permissions">
							<i>Permissions</i>
							</div>
							<div class="permission-roles">
								<div class="row">
									<div class="col-md-3">
											<label class="m-checkbox">
											<input type="checkbox" name="agency_approve" id="agency_approve" class="checkchagebox"  <?php if (isset($rolelist->agency_approve) && !empty($rolelist->agency_approve)){?> checked="checked" <?php }else{ ?> {{ old('agency_approve') ? 'checked' : '' }} <?php } ?>> Can approve agency
											<span></span>
									       </label>
									</div>
									<div class="col-md-3">
											<label class="m-checkbox">
											<input type="checkbox" name="agency_open" id="agency_open" class="checkchagebox" <?php if (isset($rolelist->agency_open) && !empty($rolelist->agency_open)){?> checked="checked" <?php }else{ ?> {{ old('agency_open') ? 'checked' : '' }} <?php } ?>> Can open agency
											<span></span>
									       </label>
									</div>
									<div class="col-md-3">
											<label class="m-checkbox">
											<input type="checkbox" name="agency_remove" id="agency_remove" class="checkchagebox" <?php if (isset($rolelist->agency_remove) && !empty($rolelist->agency_remove)){?> checked="checked" <?php }else{ ?> {{ old('agency_remove') ? 'checked' : '' }} <?php } ?>> Can remove agency
											<span></span>
									       </label>
									</div>
									<div class="col-md-3">
											<label class="m-checkbox">
											<input type="checkbox" name="agency_lock" id="agency_lock" class="checkchagebox" <?php if (isset($rolelist->agency_lock) && !empty($rolelist->agency_lock)){?> checked="checked" <?php }else{ ?> {{ old('agency_lock') ? 'checked' : '' }} <?php } ?>> Can lock agency
											<span></span>
									       </label>
									</div>
								</div>
								<div class="row">
									<div class="col-md-3">
											<label class="m-checkbox">
											<input type="checkbox" name="user_create" id="user_create" class="checkchagebox" <?php if (isset($rolelist->user_create) && !empty($rolelist->user_create)){?> checked="checked" <?php }else{ ?> {{ old('user_create') ? 'checked' : '' }} <?php } ?>> Can create users
											<span></span>
									       </label>
									</div>
									<div class="col-md-3">
											<label class="m-checkbox">
											<input type="checkbox" name="user_remove" id="user_remove" class="checkchagebox" <?php if (isset($rolelist->user_remove) && !empty($rolelist->user_remove)){?> checked="checked" <?php }else{ ?> {{ old('user_remove') ? 'checked' : '' }} <?php } ?>> Can remove users
											<span></span>
									       </label>
									</div>
									<div class="col-md-3">
											<label class="m-checkbox">
											<input type="checkbox" name="user_lock" id="user_lock" class="checkchagebox" <?php if (isset($rolelist->user_lock) && !empty($rolelist->user_lock)){?> checked="checked" <?php }else{ ?> {{ old('user_lock') ? 'checked' : '' }} <?php } ?>> Can lock users
											<span></span>
									       </label>
									</div>
									
								</div>
								<div class="row">
									<div class="col-md-3">
											<label class="m-checkbox">
											<input type="checkbox" name="approve_credit_limit" class="checkchagebox" class="checkchagebox" id="approve_credit_limit" <?php if (isset($rolelist->approve_credit_limit) && !empty($rolelist->approve_credit_limit)){?> checked="checked" <?php }else{ ?> {{ old('approve_credit_limit') ? 'checked' : '' }} <?php } ?>> Can approve credit limits
											<span></span>
									       </label>
									</div>
									<div class="col-md-3">
											<label class="m-checkbox">
											<input type="checkbox" name="approve_credit_terms" id="approve_credit_terms" class="checkchagebox" <?php if (isset($rolelist->approve_credit_terms) && !empty($rolelist->approve_credit_terms)){?> checked="checked" <?php }else{ ?> {{ old('approve_credit_terms') ? 'checked' : '' }} <?php } ?>> Can approve credit terms
											<span></span>
									       </label>
									</div>
									<div class="col-md-3">
											<label class="m-checkbox">
											<input type="checkbox" name="approve_credit_assign" id="approve_credit_assign" class="checkchagebox" <?php if (isset($rolelist->approve_credit_assign) && !empty($rolelist->approve_credit_assign)){?> checked="checked" <?php }else{ ?> {{ old('approve_credit_assign') ? 'checked' : '' }} <?php } ?>> Can assign credit limits
											<span></span>
									       </label>
									</div>
									<div class="col-md-3">
											<label class="m-checkbox">
											<input type="checkbox" name="approve_credit_assign_terms" class="checkchagebox" id="approve_credit_assign_terms" <?php if (isset($rolelist->approve_credit_assign_terms) && !empty($rolelist->approve_credit_assign_terms)){?> checked="checked" <?php }else{ ?> {{ old('approve_credit_assign_terms') ? 'checked' : '' }} <?php } ?>> Can assign credit terms
											<span></span>
									       </label>
									</div>
								</div>
								<div class="row">
									<div class="col-md-3">
											<label class="m-checkbox">
											<input type="checkbox" name="book" id="book" <?php if (isset($rolelist->book) && !empty($rolelist->book)){?> checked="checked" <?php }else{ ?> {{ old('book') ? 'checked' : '' }} <?php } ?>> Can book
											<span></span>
									       </label>
									</div>
									<div class="col-md-3">
											<label class="m-checkbox">
											<input type="checkbox" name="offline_booking" id="offline_booking" <?php if (isset($rolelist->offline_booking) && !empty($rolelist->offline_booking)){?> checked="checked" <?php }else{ ?> {{ old('offline_booking') ? 'checked' : '' }} <?php } ?>> Can input offline booking
											<span></span>
									       </label>
									</div>
									<div class="col-md-3">
											<label class="m-checkbox">
											<input type="checkbox" name="booking_confirm" id="booking_confirm" <?php if (isset($rolelist->booking_confirm) && !empty($rolelist->booking_confirm)){?> checked="checked" <?php }else{ ?> {{ old('booking_confirm') ? 'checked' : '' }} <?php } ?>> Can confirm
											<span></span>
									       </label>
									</div>
									
								</div>
								<div class="row">
									<div class="col-md-3">
											<label class="m-checkbox">
											<input type="checkbox" name="create_voucher" id="create_voucher" <?php if (isset($rolelist->create_voucher) && !empty($rolelist->create_voucher)){?> checked="checked" <?php }else{ ?> {{ old('create_voucher') ? 'checked' : '' }} <?php } ?>> Can create voucher
											<span></span>
									       </label>
									</div>
									<div class="col-md-3">
											<label class="m-checkbox">
											<input type="checkbox" name="issue_receipts" id="issue_receipts" <?php if (isset($rolelist->issue_receipts) && !empty($rolelist->issue_receipts)){?> checked="checked" <?php }else{ ?> {{ old('issue_receipts') ? 'checked' : '' }} <?php } ?>> Can issue receipts
											<span></span>
									       </label>
									</div>
									<div class="col-md-3">
											<label class="m-checkbox">
											<input type="checkbox" name="knock_off" id="knock_off" <?php if (isset($rolelist->knock_off) && !empty($rolelist->knock_off)){?> checked="checked" <?php }else{ ?> {{ old('knock_off') ? 'checked' : '' }} <?php } ?>> Can knock-off
											<span></span>
									       </label>
									</div>
								</div>
								<div class="row">
									<div class="col-md-3">
											<label class="m-checkbox">
											<input type="checkbox" name="incentive_slobs" id="incentive_slobs" <?php if (isset($rolelist->incentive_slobs) && !empty($rolelist->incentive_slobs)){?> checked="checked" <?php }else{ ?> {{ old('incentive_slobs') ? 'checked' : '' }} <?php } ?>> Incentive slobs / incentive
											<span></span>
									       </label>
									</div>
									
								</div>
								<div class="row">
									<div class="col-md-6">
											<label class="m-checkbox">
											<input type="checkbox" name="partial_refund_cancel" id="partial_refund_cancel" <?php if (isset($rolelist->partial_refund_cancel) && !empty($rolelist->partial_refund_cancel)){?> checked="checked" <?php }else{ ?> {{ old('partial_refund_cancel') ? 'checked' : '' }} <?php } ?>> Can request refund / partial cancellation /waiver
											<span></span>
									       </label>
									</div>
									<div class="col-md-6">
											<label class="m-checkbox">
											<input type="checkbox" name="approve_refund_cancel" id="approve_refund_cancel" <?php if (isset($rolelist->approve_refund_cancel) && !empty($rolelist->approve_refund_cancel)){?> checked="checked" <?php }else{ ?> {{ old('approve_refund_cancel') ? 'checked' : '' }} <?php } ?>> Can approve refund / partial cancellation /waiver
											<span></span>
									       </label>
									</div>
								</div>
								
								<div class="row">
										<div class="col-md-6">
                                        <?php if (isset($_GET['id']) && !empty($_GET['id'])){ ?> 
										
										<input type="hidden" name="roleid" value="{{$rolelist->id}}"/>
                                        <button type="submit" class="btn btn-primary">Update Role</button>
										<?php }else{?>
											<button type="submit" class="btn btn-primary">Create Role</button>
                                            <?php } ?>
										</div>
								</div>
							</div>
						</div>
                        </div>
						</form>
                   </div>						
				</div>
@endsection

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(e) {
	
	$('#agency_create_user').click(function(e) {
		if(this.checked){
		$('#agency_approve').prop('checked', false); // Unchecks it
		$('#agency_open').prop('checked', false); // Unchecks it
		$('#agency_remove').prop('checked', false); // Unchecks it
		$('#agency_lock').prop('checked', false); // Unchecks it
		$('#user_create').prop('checked', false); // Unchecks it
		$('#user_remove').prop('checked', false); // Unchecks it
		$('#user_lock').prop('checked', false); // Unchecks it
		$('#approve_credit_limit').prop('checked', false); // Unchecks it
		$('#approve_credit_terms').prop('checked', false); // Unchecks it
		$('#approve_credit_assign').prop('checked', false); // Unchecks it
		$('#approve_credit_assign_terms').prop('checked', false); // Unchecks it
		}
	});
	
	$('.checkchagebox').click(function(e) {
		if(this.checked){
		$('#agency_create_user').prop('checked', false);
		}
		
	});
    

	
});
</script>