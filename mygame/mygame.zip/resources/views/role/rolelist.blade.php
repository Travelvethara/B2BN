@extends('layouts.app')

@section('content')
<?php 
$route = 'role.roleinsert';
if (isset($rolelist) && !empty($rolelist)){ $route = 'role.roleupdate'; }
?>
<div class="m-grid__item m-grid__item--fluid m-wrapper">
					<!-- BEGIN: Subheader -->
					<div class="m-subheader ">
						<div class="d-flex align-items-center">
							<div class="mr-auto">
								<h3 class="m-subheader__title ">
								    User Role List
								</h3>
							</div>
						</div>
					</div>
					<!-- END: Subheader -->
					<div class="m-content agencies_list">
						<div class="m-portlet m-portlet-padding agency-info-tab">
						
						   <div class="data-table-block">
								<table class="table table-striped">
										<thead>
										  <tr>
											<th>Role Name 
											   
												<i class="fas fa-sort-up datatable-up-ar"></i>
											</th>
											<th>User
											   
												<i class="fas fa-sort-up datatable-up-ar"></i>
											</th>
											<th>Action
											 
											</th>
										  </tr>
										</thead>
										<tbody>
										<?php if(isset($rolelist) && !empty($rolelist)){
                                            foreach($rolelist as $rolelist_val){
										?>
										  <tr>
											<td>{{$rolelist_val->role_name}}</td>
											<td><?php if(isset($rolelistcount[$rolelist_val->id])){ echo count($rolelistcount[$rolelist_val->id]); } else{ echo '0';}?></td>
											<td>
										
											<a href=""><i class="fas fa-align-left"></i></a>
											<a href="{{route('role')}}?id={{$rolelist_val->id}}"><i class="fas fa-edit"></i></a>
											<i class="far fa-trash-alt DeleteRole" data-id="{{$rolelist_val->id}}"></i>
                                            <form id="rolelistform{{$rolelist_val->id}}" action="{{route('role.RoleDelete')}}" method="POST" style="display: none;">
                                                                              @csrf
                                               <input type="hidden" value="{{$rolelist_val->id}}" name="id"/>
                                             </form>
											</td>
										  </tr>
										
											<?php } } ?>
										

										 
										</tbody>
									  </table>
						   </div>
                        </div>
                   </div>						
				</div>
@endsection

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(e) {

   $(".DeleteRole").click(function(e){
	   var id = $(this).data('id');
	  
       var r = confirm("Are you sure you want to Delete now?");
       //cancel clicked : stop button default action 
       if (r === false) {
           return false;
        }
        
		else if(r === true){
			
			$('#rolelistform'+id).submit();
		
		
		}
        //action continues, saves in database, no need for more code


   });

	
});
</script>