@extends('layouts.app')

@section('content')

<?php 


?>

<div class="m-grid__item m-grid__item--fluid m-wrapper">
				  <div class="edit-profil-econtainer">
					<!-- BEGIN: Subheader -->
					<div class="m-subheader m-subheader-alter ">
						<div class="d-flex align-items-center">
							<div class="mr-auto">
								<h3 class="m-subheader__title ">
									Edit Profile
								</h3>
							</div>
						</div>
					</div>
					<!-- END: Subheader -->
					<div class="m-content">
						<!--Begin::Section-->
						
                        <div class="edit-profile-content">
						<form action="{{ route('profile.profileupdate') }}" method="post">
						 <input type="hidden" name="_token" value="<?php echo @csrf_token(); ?>">
												<div class="m-portlet m-portlet-padding edit-info-tab">
													<div class="row">
														<div class="col-md-12">
															<div class="form-group m-form__group">
																<input type="text" class="form-control m-input m-input--square" readonly placeholder="User ID" value="{{$userid}}">
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-12">
															<div class="form-group m-form__group">
                                                            <label>Name</label>
																<input type="text" class="form-control m-input m-input--square" i placeholder="Name" value="{{$name}}" name="name">
																<span class="error-message">  @if ($errors->has('name'))
                       						  {{ $errors->first('name') }}
                       							 @endif </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-12">
															<div class="form-group m-form__group">
                                                            <label>Phone</label>
																<input type="text" class="form-control m-input m-input--square"  placeholder="Phone" value="{{$phone}}" name="phone">
																<span class="error-message">  @if ($errors->has('phone'))
                       						  {{ $errors->first('phone') }}
                       							 @endif </span>
															</div>
														</div>
												   </div>
												   
												   <div class="row">
														<div class="col-md-12">
															<div class="form-group m-form__group">
                                                            <label>Email</label>
																<input type="text" class="form-control m-input m-input--square"  placeholder="Email" value="{{$email}}" name="email">
																<span class="error-message">  @if ($errors->has('email'))
                       						  {{ $errors->first('email') }}
                       							 @endif </span>
															</div>
														</div>
												   </div>
												    <div class="row">
														<div class="col-md-12">
															<div class="form-group m-form__group">
                                                            
															    <label class="m-checkbox">
                                                               
																<input type="checkbox" name="changepassword" class="changepassword" {{ old('changepassword') ? 'checked' : '' }}> Do you Change password
																<span></span>
																</label>
															</div>
														</div>
												   </div>
													<div class="row checkpassword" <?php if(old('changepassword')){?> style="display:black;" <?php }else{  ?> style="display:none;" <?php } ?> >
														<div class="col-md-12">
															<div class="form-group m-form__group">
                                                            <label>Password</label>
																<input type="password" class="form-control m-input m-input--square password"  placeholder="Password" name="password">
																<span class="error-message"> @if ($errors->has('password'))
                       						  {{ $errors->first('password') }}
                       							 @endif </span>
															</div>
														</div>
												   </div>
												    <div class="row checkpassword" <?php if(old('changepassword')){?> style="display:black;" <?php }else{  ?> style="display:none;" <?php } ?>>
														<div class="col-md-12">
															<div class="form-group m-form__group">
                                                            <label>Confirm Password</label>
																<input type="password" class="form-control m-input m-input--square"  placeholder="Confirm Password" name="password_confirmation">
															</div>
														</div>
												   </div>
												   
												   
												    <div class="row">
														<div class="col-md-12">
														  <input type="hidden" name="id" value="{{$id}}"/>
														  <input type="hidden" name="type" value="{{$type}}"/>
														  <input type="hidden" name="loginid" value="{{$loginid}}"/>
															<button type="submit" class="btn btn-primary">Update</button>
														</div>
													</div>
													
													
													
											</div>
									</form>
											
											
							</div>
						<!--End::Section-->

						
						<!--End::Section-->
					</div>
				  </div>	
				</div>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(e) {
	$('.changepassword').click(function(e) {
	if(this.checked){
	
	$('.checkpassword').show();

	}else{
		
		$('.checkpassword').hide();
	}
	});
});
</script>	
				
				
				
				
@endsection
