<button class="m-aside-left-close  m-aside-left-close--skin-dark " id="m_aside_left_close_btn">
					<i class="la la-close"></i>
				</button>
				<div id="m_aside_left" class="m-grid__item	m-aside-left  m-aside-left--skin-dark menuclass ">
					<!-- BEGIN: Aside Menu -->
	<div 
		id="m_ver_menu" 
		class="m-aside-menu  m-aside-menu--skin-dark m-aside-menu--submenu-skin-dark menu-alter-class" 
		m-menu-vertical="1"
		 m-menu-scrollable="0" m-menu-dropdown-timeout="500"  
		>
						<ul>
						   <li><a href="{{route('agency')}}"><i class="fas fa-chevron-circle-down"></i> <b>Agency</b><i class="fas fa-angle-right"></i></a></li>
                           <li><a href="#"><i class="fas fa-chevron-circle-down"></i> <b>Agency List</b><i class="fas fa-angle-right"></i></a></li>
						   <li><a href="{{route('role')}}"><i class="fas fa-chevron-circle-down"></i> <b>Role</b><i class="fas fa-angle-right"></i></a></li>
						 
						</ul>
					</div>
					<!-- END: Aside Menu -->
				</div>