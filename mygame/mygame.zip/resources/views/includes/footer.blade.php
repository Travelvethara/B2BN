<footer class="m-grid__item		m-footer ">
				<div class="m-container m-container--fluid m-container--full-height m-page__container">
					<div class="m-stack m-stack--flex-tablet-and-mobile m-stack--ver m-stack--desktop">
						<div class="m-stack__item m-stack__item--left m-stack__item--middle m-stack__item--last">
							<span class="m-footer__copyright">
								2017 &copy; Metronic theme by
								<a href="https://keenthemes.com" class="m-link">
									Keenthemes
								</a>
							</span>
						</div>
					</div>
				</div>
			</footer>
				<!-- end::Footer -->
		</div>
		<!-- end:: Page -->
    	 <!-- begin::Quick Sidebar -->
		
		<!-- end::Quick Sidebar -->		    
	    <!-- begin::Scroll Top -->
		<div id="m_scroll_top" class="m-scroll-top">
			<i class="la la-arrow-up"></i>
		</div>
		<!-- end::Scroll Top -->		    
		<!-- begin::Quick Nav -->
		
		<!-- begin::Quick Nav -->	
    	<!--begin::Base Scripts -->
		<script src="/js/vendors.bundle.js" type="text/javascript"></script>
		<script src="/js/scripts.bundle.js" type="text/javascript"></script>
		<!--end::Base Scripts -->   
        <!--begin::Page Vendors -->
		<script src="/js/fullcalendar.bundle.js" type="text/javascript"></script>
		<!--end::Page Vendors -->  
        <!--begin::Page Snippets -->
		<script src="/js/dashboard.js" type="text/javascript"></script>
		
		<!--end::Page Snippets -->
         
	</body>
	<!-- end::Body -->
	<!-- end::Body -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script>
		$(document).ready(function(){
		var winheight = $(window).innerHeight();
		var abovelist = $(".list-lists").offset().top;
		
		var fin_height = winheight - abovelist;
		
      	
        $(".list-lists, .list-filters, .Hotel-detail-lists").css("height",fin_height);
		 
		
		if ( $('.m-content').hasClass('list-page')) {
			
			$(".m-wrapper").css("margin-bottom",0);
			$(".m-content").css("padding-bottom",0);
			$(".m-content").css("padding-left",15);
			$(".m-content").css("padding-right",15);
		}
		
		  $(".list-filters").slimScroll({
       alwaysVisible: true
          });
		
		
    });
</script>
<script>
		$(document).ready(function(){
			
			var winheight = $(window).innerHeight();
			var abovedetaillist = $(".Hotel-detail-lists").offset().top;
			var fin_heightdetail = winheight - abovedetaillist;
			$(".Hotel-detail-lists, .list-filters").css("height",fin_heightdetail);
			 });
			 
			 if ( $('.m-content').hasClass('list-page')) {
			
			$(".m-wrapper").css("margin-bottom",0);
			$(".m-content").css("padding-bottom",0);
			$(".m-content").css("padding-left",15);
			$(".m-content").css("padding-right",15);
		}
</script>

<!--<$(document).ready(function(){
	
//var winheight = $(window).innerHeight();
//var abovelist = $(".data-table-block").offset().top;
//var fin_height = winheight - abovelist;

//$(".data-table-block").css("max-height",fin_height);

//if ( $('.m-content').hasClass('agencies_list')) {
			
	//		$(".m-wrapper").css("margin-bottom",0);
	//		$(".m-content").css("padding-bottom",15);
	//		$(".m-content").css("padding-left",15);
	//	$(".m-content").css("padding-right",15);
	//	}

 // });-->
  
  

	
</html>