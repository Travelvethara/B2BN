
			<!-- BEGIN: Header -->
			 <?php 
			 require_once('header.php'); 
			 
			 ?>
			<!-- END: Header -->
					
		<!-- begin::Body -->
			<div class="m-grid__item m-grid__item--fluid m-grid m-grid--ver-desktop m-grid--desktop m-body">
				<!-- BEGIN: Left Aside -->
				   <?php 
			 require_once('menu.php'); 
			 
			 ?>
				<!-- END: Left Aside -->
				<div class="m-grid__item m-grid__item--fluid m-wrapper">
					<!-- BEGIN: Subheader -->
                     <div class="m-subheader ">
						<div class="d-flex align-items-center">
							<div class="mr-auto">
								<h3 class="m-subheader__title ">
									Agency Information
								</h3>
							</div>
						</div>
					</div>
					<!-- END: Subheader -->
					<div class="m-content agencies_list">
						<div class="m-portlet m-portlet-padding agency-info-tab">
						
						  <div class="view-ageny-page">
							<div class="row">
								<div class="col-md-6 agencyname">
									Agency Name
								</div>
								<div class="col-md-6">
									<b>Agency ID:</b>AGN548963
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
								<b>Agency Level:</b>AGN548963
								</div>
								<div class="col-md-6">
									<b>Manager:</b>First Name
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
								<b>Street Address:</b>441 Mount eden Road, Mount Eden, Auckland.
								</div>
							</div>	
						  </div>
						  <div class="row booking-refunf-agen">
								<div class="col-md-12">
									<div class="booking-refunf-agen-display">
										<a href="#">Bookings</a>
									</div>
										<div class="booking-refunf-agen-display">
										<a href="#">Refunds</a>
									</div>
										<div class="booking-refunf-agen-display">
										<a href="#">Users</a>
									</div>
										<div class="booking-refunf-agen-display">
										<a href="#">Sub Agency</a>
									</div>
								</div>
						   </div>
                            <div class="credit-accept-decline">
                             <div class="row">
									<div class="col-md-4">
										Current limit:<span>$3</span> 
									</div>
									<div class="col-md-4">
										Current Mark Up:<span>0%</span> 
									</div>
							 </div>
							 <div class="row">
								<div class="col-md-12">
									Manager Assigned <span>$500</span> Credit limit 
                                    <div class="cCredit-accept-decline">
										<div class="credit-accept">
											<button class="btn btn-success"> Accept</button>
										</div>
										<div class="credit-decline">
										<button class="btn btn-danger"> Decline</button>
										</div>
                                    </div>									
								</div>
							 </div>
							 <div class="row creditlimit-newmarkup">
								<div class="col-md-4">
									<div class="form-group m-form__group">
										<label for="exampleInputEmail1">New Credit Limit</label>
										<input type="text" class="form-control m-input"  placeholder="New Credit Limit">
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group m-form__group">
										<label for="exampleInputEmail1">New Markup %</label>
										<input type="text" class="form-control m-input"  placeholder="New Markup %">
									</div>
								</div>
								<div class="col-md-4">
								  <label class="displayblock">Approve</label>
									<span class="m-switch">
												<label>
						                        <input type="checkbox" checked="checked" name="">
						                        <span></span>
						                        </label>
						            </span>
								</div>
							 </div>
							    </div>	
							 <div class="update-edit-btn">
							   <div class="update-btn">
								<button type="submit" class="btn btn-primary"> Update </button>
							   </div>
                                <div class="update-btn update-edit">
								<button type="button" class="btn btn-metal"> Edit </button>
							   </div>							   
							 </div>
                         						
						  </div>
						  
                        </div>
                   </div>						
				</div>
			</div>
			
			<!-- end:: Body -->
            <!-- begin::Footer -->
			<?php
			require_once('footer.php'); 
			?>
			<!-- end:: Footer -->
