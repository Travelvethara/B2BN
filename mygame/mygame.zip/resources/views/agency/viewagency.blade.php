@extends('layouts.app')

@section('content')

<?php 
//print_r($role_type);
?>
<!-- END: Left Aside -->
				<div class="m-grid__item m-grid__item--fluid m-wrapper">
					<!-- BEGIN: Subheader -->
                     <div class="m-subheader ">
						<div class="d-flex align-items-center">
							<div class="mr-auto">
								<h3 class="m-subheader__title ">
									Agency Information
								</h3>
							</div>
						</div>
					</div>
					<!-- END: Subheader -->
					<div class="m-content agencies_list">
						<div class="m-portlet m-portlet-padding agency-info-tab">
						
						  <div class="view-ageny-page">
							<div class="row">
								<div class="col-md-6 agencyname">
									Agency Name {{$agency->aname}}
								</div>
								<div class="col-md-6">
									<b>Agency ID:</b>{{$agency->userid}}
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
								<b>Agency Level:</b>
                                @if($agency->parentagencyid == 0) 
                               		<?php echo "Parant Agency"; ?>
                                @else
                                	<?php echo "Sub Agency"; ?>
								@endif                                
								</div>
								<div class="col-md-6">
									<b>Manager:</b> {{$agency->aname}}
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
								<b>Street Address:</b>{{$agency->address1}}, {{$agency->address2}}, {{$agency->city}}, {{$agency->country}}
								</div>
							</div>	
						  </div>
						  <div class="row booking-refunf-agen">
								<div class="col-md-12">
									<div class="booking-refunf-agen-display">
										<a href="#">Bookings</a>
									</div>
										<div class="booking-refunf-agen-display">
										<a href="#">Refunds</a>
									</div>
										<div class="booking-refunf-agen-display">
										<a href="#">Users</a>
									</div>
										<div class="booking-refunf-agen-display">
										<a href="#">Sub Agency</a>
									</div>
								</div>
						   </div>
                           <form method="POST" action="{{ route('agency.updateagency') }}" />
                           		<input type="hidden" name="_token" value="<?php echo @csrf_token(); ?>">
                            <input type="hidden" name="id" value="<?php if(isset($_GET['id']) && !empty($_GET['id'])) { echo $_GET['id']; } ?>"/>
                            <div class="credit-accept-decline">
                             <div class="row">
									<div class="col-md-4">
										Current limit:<span>$ {{$agency->current_credit_limit}}</span> 
									</div>
									<?php if($role_type == 'SuperAdmin') { ?>
                                    <div class="col-md-4">
										Current Mark Up:<span>{{$agency->current_markup}} %</span> 
									</div>
                                    <?php } ?>
							 </div>
                             <?php if($role_type == 'SuperAdmin' && $agency->requested_amount > 0) { ?>
							 <div class="row">
								<div class="col-md-12">
									 Manager Requested <span>$</span> <span id="amount"> <?php echo $agency->requested_amount; ?></span> Credit limit 
                                    <div class="cCredit-accept-decline">                                    
										<div class="credit-accept">
											<button type="button" class="btn btn-success" id="acceptbutton"> Accept</button>
										</div>
										<div class="credit-decline">
										<button type="button" class="btn btn-danger" id="declinebutton"> Decline</button>
										</div>
                                    </div>									
								</div>
							 </div>
                             <?php } ?>
                             
                             <?php if($role_type == 'AgencyManger' && $agency->requested_amount > 0) { ?>
							 <div class="row">
								<div class="col-md-12">
									 You have requested <span>$</span> <span id="amount"> <?php echo $agency->requested_amount; ?></span> Credit limit 
                                    <div class="cCredit-accept-decline">                                    
										Waiting for Approval
                                    </div>									
								</div>
							 </div>
                             <?php } ?>

							 <div class="row creditlimit-newmarkup">
								<div class="col-md-4">
									<div class="form-group m-form__group">
										<label for="exampleInputEmail1">New Credit Limit</label>
										<input type="text" class="form-control m-input" name="newcreditlimit" id="newcreditlimit" value=""  placeholder="New Credit Limit">
                                        <span class="error-message">   @if ($errors->has('newcreditlimit'))
                                          {{ $errors->first('newcreditlimit') }}
                                        @endif    </span>
									</div>
                                    	
								</div>
								<?php if($role_type == 'SuperAdmin') { ?>
                                <div class="col-md-4">
									<div class="form-group m-form__group">
										<label for="exampleInputEmail1">New Markup %</label>
										<input type="text" class="form-control m-input" name="newmarkup" value="" placeholder="New Markup %">
									</div>
								</div>
                                <?php } ?>
                                
                                <?php if($role_type == 'SuperAdmin') { ?>
								<div class="col-md-4">
								  <label class="displayblock">Approve</label>
									<span class="m-switch">
												<label>
						                        <input type="checkbox" <?php if($agency->activestatus == 1) { ?>checked="checked" <?php } ?> name="activestatus">
						                        <span></span>
						                        </label>
						            </span>
								</div>
                                <?php } ?>
							 </div>
							    </div>
                                <input type="hidden" name="requestedstatus" id="requestedstatus" value=""/>
							 <div class="update-edit-btn">
							   <div class="update-btn">
								<button type="submit" class="btn btn-primary"> <?php if($role_type == 'SuperAdmin') { ?> Update <?php } else { ?> Request Credit Limit <?php } ?></button>
							   </div>
                                <div class="update-btn update-edit">
								<button type="button" class="btn btn-metal"> Edit </button>
							   </div>							   
							 </div>
						  </div>
						  
                        </div>
                   </div>
                </form>
			
			
			<!-- end:: Body -->
            <!-- begin::Footer -->
            
            @endsection
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>

$(document).ready(function () {
	
	$(function() {
	  $('.priceparent').on('keydown', '.price', function(e){-1!==$.inArray(e.keyCode,[46,8,9,27,13,110,190])||(/65|67|86|88/.test(e.keyCode)&&(e.ctrlKey===true||e.metaKey===true))&&(!0===e.ctrlKey||!0===e.metaKey)||35<=e.keyCode&&40>=e.keyCode||(e.shiftKey||48>e.keyCode||57<e.keyCode)&&(96>e.keyCode||105<e.keyCode)&&e.preventDefault()});
	})
	
	$(document).on('change', '.price', function(){
		var numb = $(this).val();
		var zzz = (parseFloat(numb) || 0).toFixed(2);
		$(this).val(zzz);
	});
	
	$(document).on('click', '#acceptbutton', function(){
		var assignedamount =$("#amount").html();
		$("#newcreditlimit").val(assignedamount);
		$("#requestedstatus").val('approved');
	});
	
	
	$(document).on('click', '#declinebutton', function(){
		$("#newcreditlimit").val('');
		$("#requestedstatus").val('declined');
	});
	
});

</script>

