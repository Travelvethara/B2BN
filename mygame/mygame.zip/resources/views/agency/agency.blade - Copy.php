@extends('layouts.app')

@section('content')

<?php 
$route = 'agency.agencystore';
if (isset($agency) && !empty($agency)){
$route = 'agency.agencyupdate';
}
//active tab
$activetab = 'active show';

$activecon = 'active';

$activecon2 = '';

$activetab2 = '';

if(isset($_GET['id']) && !empty($_GET['id'])){
	if($_GET['tab'] == 1){
	$activetab = 'active show';
	$activecon = 'active';
	}
	if($_GET['tab'] == 2){
		$activetab= '';
		$activecon = '';
		$activecon2 = 'active';
		$activetab2 = 'active show';
	
	}
	


}

?>



	<!-- END: Left Aside -->
				<div class="m-grid__item m-grid__item--fluid m-wrapper">
					<!-- BEGIN: Subheader -->
					<div class="m-subheader ">
						<div class="d-flex align-items-center">
							<div class="mr-auto">
								<h3 class="m-subheader__title ">
									Create Agency
								</h3>
							</div>
						</div>
					</div>
					<!-- END: Subheader -->
					<div class="m-content">
						<!--Begin::Section-->
						<div class="row">
							<ul class="nav nav-tabs  m-tabs-line m-tabs-line--primary" role="tablist">
											<li class="nav-item m-tabs__item">
												<a class="nav-link m-tabs__link managerdetails {{$activetab}}" data-toggle="tab" href="#m_tabs_6_1" role="tab" aria-selected="false">
                                                    Manager Details
												</a>
											</li>
									<?php if(isset($_GET['id']) && !empty($_GET['id'])){?>
											<li class="nav-item m-tabs__item">
												<a class="nav-link m-tabs__link agencyinfo {{$activetab2}}" data-toggle="tab" href="#m_tabs_6_3" role="tab" aria-selected="true">
													Agency Information
												</a>
											</li>
                                            <?php } ?>
										</ul>
						</div>
                        <div class="tab-content">
											<div class="tab-pane {{$activecon}}" id="m_tabs_6_1" role="tabpanel">
								<form action="{{ route($route) }}" method="post">
                                    
                                  <input type="hidden" name="_token" value="<?php echo @csrf_token(); ?>">
                                  
												<div class="m-portlet m-portlet-padding agency-info-tab">
													<div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
					<input type="text" name="name" class="form-control m-input m-input--square"  placeholder="Name" <?php if (isset($agency->name) && !empty($agency->name)){ ?> value="{{ $agency->name}}" <?php }else{ ?> value="{{ old('name') }}" <?php } ?>>
                   	<span class="error-message">   @if ($errors->has('name'))
                       	  {{ $errors->first('name') }}
                        @endif    </span>

															</div>
														</div>
														<div class="col-md-6 ">
															<div class="form-group m-form__group">
					<input type="email" name="email" class="form-control m-input m-input--square"  aria-describedby="emailHelp" placeholder="Email" <?php if (isset($agency->email) && !empty($agency->email)){ ?> value="{{ $agency->email }}" <?php } else{ ?> value="{{ old('email') }}" <?php } ?>>
                    	<span class="error-message">  @if ($errors->has('email'))
                       						  {{ $errors->first('email') }}
                       							 @endif </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
					<input type="text" name="phone" id="phone" class="form-control m-input m-input--square" i placeholder="Phone" <?php if (isset($agency->phone) && !empty($agency->phone)){?> value="{{ $agency->phone }}" <?php }else{ ?>value="{{old('phone')}}"<?php } ?>>
                    						<span class="error-message">  @if ($errors->has('phone'))
                       						  {{ $errors->first('phone') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
					<input type="text" name="mobile" id="mobile" class="form-control m-input m-input--square"  placeholder="Mobile"  <?php if (isset($agency->mobile) && !empty($agency->mobile)){?> value="{{ $agency->mobile }}" <?php }else{ ?>value="{{old('mobile')}}"<?php } ?>>
                    							<span class="error-message">  @if ($errors->has('mobile'))
                       						  {{ $errors->first('mobile') }}
                       							 @endif </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
					<input type="text" name="whatsapp" id="whatsapp" class="form-control m-input m-input--square"  placeholder="whatsapp" <?php if (isset($agency->whatapp) && !empty($agency->whatsapp)){?> value="{{ $agency->whatsapp }}" <?php }else{ ?>value="{{old('whatsapp')}}"<?php } ?>>
                    							<span class="error-message">  @if ($errors->has('whatsapp'))
                       						  {{ $errors->first('whatsapp') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
					<input type="text" name="userid" class="form-control m-input m-input--square" readonly  placeholder="User ID">
                    					
															</div>
														</div>
												   </div>
                                  <?php if (empty($agency->userid)){ ?>                 
												    <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
					<input type="password" name="password" class="form-control m-input m-input--square" placeholder="Password" >
                    			<span class="error-message"> @if ($errors->has('password'))
                       						  {{ $errors->first('password') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
					<input type="password" name="password_confirmation" class="form-control m-input m-input--square"  placeholder="Confirm Password">
                    					
															</div>
														</div>
												   </div>
                                               <?php } ?>    
												   <div class="row">
														<div class="col-md-6">
															<div class="m-form__group form-group row">
															<div class="col-2">
																	<span class="m-switch m-switch--icon m-switch--success">
																		<label>
												<input type="checkbox" checked="checked" name="account_status">
																		<span></span>
																		</label>
																	</span>
																</div>
																<label class="col-2 col-form-label">Active</label>
																
									                         </div>
														</div>
												   </div>
												    <div class="row">
														<div class="col-md-6">
                                                             <?php if (!empty($agency->userid)){  ?> 
															 <input type="hidden" name="userid" value="{{$agency->userid}}"/>
                                                             <input type="hidden" name="agencyid" value="{{$agency->id}}"/>
															 
															 <?php }  ?>
															<button type="submit" name="create_agencyy" class="btn btn-primary">Create Agency</button>
														</div>
													</div>
											</div>
											</div>
                                            </form>
                                            <!------- create agency---------->
											<div class="tab-pane {{$activecon2}}" id="m_tabs_6_3" role="tabpanel">
												<div class="m-portlet m-portlet-padding agency-info-tab">
                                 		<form action="{{ route('agency.agencymanager') }}" method="POST">
                                         <input type="hidden" name="_token" value="<?php echo @csrf_token(); ?>">
                                         <?php if (!empty($agency->userid)){  ?> 
                                                <input type="hidden" name="agency_id" value="{{$agency->id}}"/>
										<?php }  ?>
													<div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
			<input type="text" class="form-control m-input m-input--square"  name="aname"  placeholder="Agency Name"<?php if (isset($agency->aname) && !empty($agency->aname)){?> value="{{ $agency->aname }}" <?php }else{ ?>value="{{old('aname')}}"<?php } ?> >
                            <span class="error-message">  @if ($errors->has('aname'))
                       						  {{ $errors->first('aname') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
		<input type="email" class="form-control m-input m-input--square" name="aemail" aria-describedby="emailHelp" placeholder="Email" <?php if (isset($agency->aemail) && !empty($agency->aemail)){?> value="{{ $agency->aemail }}" <?php }else{ ?>value="{{old('aemail')}}"<?php } ?>>
                    <span class="error-message">  @if ($errors->has('aemail'))
                       						  {{ $errors->first('aemail') }}
                       							 @endif </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
							<input type="text" class="form-control m-input m-input--square"  name="address1" placeholder="Address Line 1"<?php if (isset($agency->address1) && !empty($agency->address1)){?> value="{{ $agency->address1 }}" <?php }else{ ?>value="{{old('address1')}}"<?php } ?>>
                             <span class="error-message">  @if ($errors->has('address1'))
                       						  {{ $errors->first('address1') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
							<input type="text" class="form-control m-input m-input--square" name="address2" placeholder="Address Line 2"<?php if (isset($agency->address2) && !empty($agency->address2)){?> value="{{ $agency->address2 }}" <?php }else{ ?>value="{{old('address2')}}"<?php } ?>>
                             
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
							<input type="text" class="form-control m-input m-input--square"  name="country"  placeholder="Country" <?php if (isset($agency->country) && !empty($agency->country)){?> value="{{ $agency->country }}" <?php }else{ ?>value="{{old('country')}}"<?php } ?>>
                             <span class="error-message">  @if ($errors->has('country'))
                       						  {{ $errors->first('country') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
							<input type="text" class="form-control m-input m-input--square" name="city"  placeholder="City" <?php if (isset($agency->city) && !empty($agency->city)){?> value="{{ $agency->city }}" <?php }else{ ?>value="{{old('city')}}"<?php } ?>>
                               <span class="error-message">  @if ($errors->has('city'))
                       						  {{ $errors->first('city') }}
                       							 @endif </span>
															</div>
														</div>
												   </div>
												    <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
							<input type="text" class="form-control m-input m-input--square"  name="zip" id="zip" placeholder="Zip / Postal Code"  <?php if (isset($agency->zip) && !empty($agency->zip)){?> value="{{ $agency->zip }}" <?php }else{ ?>value="{{old('zip')}}"<?php } ?>>
                             <span class="error-message">  @if ($errors->has('zip'))
                       						  {{ $errors->first('zip') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
							<input type="text" class="form-control m-input m-input--square" name="amobile" id="mobile1"  placeholder="Mobile" <?php if (isset($agency->amobile) && !empty($agency->amobile)){?> value="{{ $agency->amobile }}" <?php }else{ ?>value="{{old('amobile')}}"<?php } ?>>
                            <span class="error-message">  @if ($errors->has('amobile'))
                       						  {{ $errors->first('amobile') }}
                       							 @endif </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                          
							<input type="text" class="form-control m-input m-input--square"  name="aphone" id="phone1"  placeholder="phone" <?php if (isset($agency->aphone) && !empty($agency->aphone)){?> value="{{ $agency->aphone }}" <?php }else{ ?>value="{{old('aphone')}}"<?php } ?>>
                              <span class="error-message">  @if ($errors->has('aphone'))
                       						  {{ $errors->first('aphone') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
							<input type="text" class="form-control m-input m-input--square"   name="awhatsapp" id="whatsapp1" placeholder="Whatsapp" <?php if (isset($agency->awhatsapp) && !empty($agency->awhatsapp)){?> value="{{ $agency->awhatsapp }}" <?php }else{ ?>value="{{old('awhatsapp')}}"<?php } ?>>
                                <span class="error-message">  @if ($errors->has('awhatsapp'))
                       						  {{ $errors->first('awhatsapp') }}
                       							 @endif </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
							<input type="text" class="form-control m-input m-input--square"  name="skype" id="skype" placeholder="Skype" <?php if (isset($agency->skype) && !empty($agency->skype)){?> value="{{ $agency->skype }}" <?php }else{ ?>value="{{old('skype')}}"<?php } ?>>
                             <span class="error-message">  @if ($errors->has('skype'))
                       						  {{ $errors->first('skype') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
							<input type="text" class="form-control m-input m-input--square"  name="website" placeholder="Website"<?php if (isset($agency->website) && !empty($agency->website)){?> value="{{ $agency->website }}" <?php }else{ ?>value="{{old('website')}}"<?php } ?>>
                               <span class="error-message">  @if ($errors->has('website'))
                       						  {{ $errors->first('website') }}
                       							 @endif </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
							 <input type="text" class="form-control m-input m-input--square" name="register_number"  id="register_number"  placeholder="Company Registration number" <?php if (isset($agency->register_number) && !empty($agency->register_number)){?> value="{{ $agency->register_number }}" <?php }else{ ?>value="{{old('register_number')}}"<?php } ?>>
                               <span class="error-message">  @if ($errors->has('register_number'))
                       						  {{ $errors->first('register_number') }}
                       							 @endif </span>
															</div>
														</div>
														
												   </div>
												 
												    <div class="row">
														<div class="col-md-6">
                                                         
									<button type="submit" class="btn btn-primary">Update Manager Details</button>
														</div>
													</div>
											</div>
                                            </form>
											</div>
							</div>
						<!--End::Section-->

						
						<!--End::Section-->
					</div>
				</div>
		
			<!-- end:: Body -->
            <!-- begin::Footer -->
								 <?php if(isset($_GET['id']) && !empty($_GET['id'])){?>           
                                <input type="hidden" id="homeurl" value="<?php echo URL::to("/agency?id=".$_GET['id']);?>"/>
                                <?php } ?>
@endsection
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function (){
$("#phone").keypress(function (e) {
  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
       }
	   else
	   {
		 $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });
$("#mobile").keypress(function (e) {
  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
		  
                 return false;
       }
	   else
	   {
		 $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });	 
$("#whatsapp").keypress(function (e) {
  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
       }
	   else
	   {
		  $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });
	 
	 //Thana Start
	 
	 $("#zip").keypress(function (e) {
  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
       }
	   else
	   {
		 $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });
	 
	 
	 $("#mobile1").keypress(function (e) {
  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
       }
	   else
	   {
		 $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });
	 
	 
	 	 $("#phone1").keypress(function (e) {
  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
       }
	   else
	   {
		 $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });
	 
	 
	  $("#whatsapp1").keypress(function (e) {
  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
       }
	   else
	   {
		 $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });
	 
	 
	 	  $("#skype").keypress(function (e) {
  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
       }
	   else
	   {
		 $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });
	 
	 
	 
	 	  $("#register_number").keypress(function (e) {
  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
       }
	   else
	   {
		 $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });
	 	
	 //Thana End	  
});
</script>

<?php if(isset($_GET['id']) && !empty($_GET['id'])){?>
<script>
$(document).ready(function (){


$('.managerdetails').click(function (){
	var url = $('#homeurl').val();
    window.history.pushState('', '', url+'&tab=1');
});

$('.agencyinfo').click(function (){
	var url = $('#homeurl').val();
    window.history.pushState('', '', url+'&tab=2');
});
	
	

	
});

</script>
<?php } ?> 
<style>
#errmsg
{
 color:red;
}

.error-message {
    color: #ff3c41;
    padding: 5px 10px;
    margin-left: 0;
    width: 100%;
}
</style>