@extends('layouts.app')

@section('content')
				<!-- END: Left Aside -->
				<div class="m-grid__item m-grid__item--fluid m-wrapper">
					<!-- BEGIN: Subheader -->
					<div class="m-subheader ">
						<div class="d-flex align-items-center">
							<div class="mr-auto">
								<h3 class="m-subheader__title ">
								    User List
								</h3>
							</div>
						</div>
					</div>
					<!-- END: Subheader -->
					<div class="m-content agencies_list">
						<div class="m-portlet m-portlet-padding agency-info-tab">
						
						   <div class="data-table-block">
								<table class="table table-striped">
										<thead>
										  <tr> <th>S No</th>
											<th>User Name 
											   <i class="fas fa-sort-down datatable-down-ar"></i>
												<i class="fas fa-sort-up datatable-up-ar"></i>
											</th>
											<th>User Role
											    <i class="fas fa-sort-down datatable-down-ar"></i>
												<i class="fas fa-sort-up datatable-up-ar"></i>
											</th>
											<th>User ID
											  
											</th>
											<th>Status

											</th>
											<th>Action
											 
											</th>
										  </tr>
										</thead>
										<tbody>
										  <?php $i =1; ?>
                                         @foreach ($products as $details)
                                            <tr>
                                               <td>{{ $i }}</td>
                                               <td>{{ $details->name}}</td>
                                               
                                               <td>{{ $details->role_name }}</td>
                                               <td>{{ $details->userid }}</td>
                                              
                                               <td><?php if(isset($details->activestatus) && ($details->activestatus != 0)) { ?> Active <?php
                               } else { ?> Locked <?php } ?> </td>
                               					<td>
                                                    <a href="{{route('userupdate')}}?id={{$details->id}}" target="_blank"><i class="fas fa-eye" data-id="1"></i></a>
													<a href="{{route('userupdate')}}?id={{$details->id}}" target="_blank"><i class="fas fa-edit"></i></a>
													<a href="{{route('userdelete')}}?id={{$details->id}}" target="_blank"><i class="far fa-trash-alt"></i></a>
                               					</td>
                                               </tr>    
                                         <?php $i++; ?>
                                         @endforeach
                                     
                                    <div id="">
                                    </div>    

										 
										</tbody>
									  </table>
						   </div>
                        </div>
                   </div>						
				</div>
			</div>
			
			<!-- end:: Body -->
             
            @endsection
			<!-- end:: Footer -->
