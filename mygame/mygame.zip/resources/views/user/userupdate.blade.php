
@extends('layouts.app')

@section('content')
<?php 
$route = 'userinsert';
if (isset($user) && !empty($user)){
$route = 'userupdate';
}



?>
				<!-- END: Left Aside -->
				<div class="m-grid__item m-grid__item--fluid m-wrapper">
					<!-- BEGIN: Subheader -->
					<div class="m-subheader ">
						<div class="d-flex align-items-center">
							<div class="mr-auto">
								<h3 class="m-subheader__title ">
									Update User
								</h3>
							</div>
						</div>
					</div>
					<!-- END: Subheader -->
					<div class="m-content">
						<!--Begin::Section-->
						
                        <div class="user-content">
							<form action="{{ route($route) }}" method="post">
                                    
                                  <input type="hidden" name="_token" value="<?php echo @csrf_token(); ?>">
                                 
											
												<div class="m-portlet m-portlet-padding user-info">
													<div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Name</label>
																<input type="text" class="form-control m-input m-input--square" name="name" placeholder="Name"<?php if (isset($user->name) && !empty($user->name)){?>  value = "{{ $user->name }}" <?php }else{ ?>value="{{old('name')}}" <?php } ?>><span class="error-message">  @if ($errors->has('name'))
                       						  {{ $errors->first('name') }}
                       							 @endif </span>
															</div>
														</div>
                                                        <div class="col-md-6 ">
															<div class="form-group m-form__group">
                                                            <label>Email</label>
																<input type="email" class="form-control m-input m-input--square"  name="email" aria-describedby="emailHelp" placeholder="Email" <?php if (isset($user->email) && !empty($user->email)){?>  value = "{{ $user->email }}" <?php }else{ ?>value="{{old('email')}}"<?php } ?>><span class="error-message">  @if ($errors->has('email'))
                       						  {{ $errors->first('email') }}
                       							 @endif </span>
															</div>
														</div>
                                                      </div>
                                                      
                                                    <div class="row" id="passcheck" >
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Password</label>
																<input type="password" class="form-control m-input m-input--square" name="password" placeholder="Password" <?php if (isset($user->password) && !empty($user->password)){?>  value = "{{ $user->password }}" <?php }else{ ?>value="{{old('password')}}"<?php } ?>><span class="error-message">  @if ($errors->has('password'))
                       						  {{ $errors->first('password') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Confirm Password</label>
																<input type="password" class="form-control m-input m-input--square" name="password_confirmation" placeholder="Confirm Password">
															</div>
														</div>
												   </div>
                                                   
                                                   
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Phone</label>
																<input type="text" id = "phone" name="phone" class="form-control m-input m-input--square" i placeholder="Phone" <?php if (isset($user->phone) && !empty($user->phone)){?>  value = "{{ $user->phone }}" <?php }else{ ?>value="{{old('phone')}}"<?php } ?>>
                    						<span class="error-message">  @if ($errors->has('phone'))
                       						  {{ $errors->first('phone') }}
                       							 @endif </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Mobile</label>
																<input type="text" id = "mobile" name="mobile" class="form-control m-input m-input--square"  placeholder="Mobile" <?php if (isset($user->mobile) && !empty($user->mobile)){?>  value = "{{ $user->mobile }}" <?php }else{ ?>value="{{old('mobile')}}"<?php } ?>><span class="error-message">  @if ($errors->has('mobile'))
                       						  {{ $errors->first('mobile') }}
                       							 @endif </span>
															</div>
															</div>
														</div>
												   
												   
												   
                                                   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>User role</label>
															<select class="form-control m-input m-input--square" value="id" name="roleid">                                  <option selected="selected">-Select-</option>
                                                      @foreach ($role as $row)
                                              <option value="<?php echo $row->id; ?>"><?php echo $row->role_name ?></option>;                                                          @endforeach
													</select>               
													</select>
															</div>
														</div>
                                                         <div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Userid</label>
																<input type="text"   <?php if (isset($user->userid) && !empty($user->userid)){?>  value = "{{ $user->userid }}" <?php }else{ ?>value="{{old('userid')}}"<?php } ?>class="form-control m-input m-input--square" readonly  placeholder="" >
															</div>
														</div>
														
												   </div>
                                                   
                                                  
												   <div class="row user-border-bottom">
														<div class="col-md-6">
															<div class="m-form__group form-group row">
															<div class="col-2">
																	<span class="m-switch m-switch--icon m-switch--success">
																		<label>
																		<input type="checkbox" checked="checked" name="">
																		<span></span>
																		</label>
																	</span>
																</div>
																<label class="col-2 col-form-label">Active</label>
																
									                         </div>
														</div>
												   </div>
												   <div class="row">
												    <div class="col-md-12">
													  <div class="form-group m-form__group">
														<label class="m-checkbox m-checkbox--square">
															<input type="checkbox" id="agent"> Agent level user
															<span></span>
														</label>
													   </div>	
													</div>
                                                    
                                                     <div class="col-md-12">
													  <div class="form-group m-form__group">
														<label class="m-checkbox m-checkbox--square">
															<input type="checkbox" id="pass"> If You Change Password
															<span></span>
														</label>
													   </div>	
													</div>
													</div>
													<div class="row" id="aname" style="display:none;">
													    <div class="col-md-6">
														  <div class="form-group m-form__group" >
                                                          <label>Agent name</label>
															<select class="form-control m-input m-input--square" value="id" name="agentid">
																	 <option value="0">-Select-</option>
																		@foreach($agency as $ag)
                                                      <option value="<?php echo $ag->id; ?>" <?php if($ag->id == $user->userid) { ?> selected="selected" <?php } ?>><?php echo $ag->name; ?></option>                                                                    @endforeach
															</select>
														   </div>	
														</div>	
													</div>
												    <div class="row">
														<div class="col-md-6">
                                                         <?php if (!empty($user->loginid)){  ?> 
															 <input type="hidden" name="loginid" value="{{$user->loginid}}"/>
                                                             <input type="hidden" name="userid" value="{{$user->id}}"/>
															 
															 <?php }  ?>
															<button type="submit" class="btn btn-primary">Update user</button>
														</div>
													</div>
											</div>
							</div>
						<!--End::Section-->
               
						
						<!--End::Section-->
					</div>
				</div> </form>
             </div>
			
			<!-- end:: Body -->
            <!-- begin::Footer -->
			@endsection
			<!-- end:: Footer -->
             <?php if(isset($_GET['id']) && !empty($_GET['id'])){?>           
                                <input type="hidden" id="homeurl" value="<?php echo URL::to("/userupdate?id=".$_GET['id']);?>"/>
                                <?php } ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function (){
$("#phone").keypress(function (e) {

  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
       }
	   else
	   {
		 $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });	
$("#mobile").keypress(function (e) {

  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
       }
	   else
	   {
		 $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });	
	
	$("#agent").click(function(){
  // action goes here!!
      if($("#agent").is(':checked')){
		//agency = 1;
		//alert(agency);
			  $("#aname").show();
			} else {
				//agency = 0;
		//alert(agency);
				 $("#aname").hide();
		}
		});
		
$("#pass").click(function(){
  // action goes here!!
      if($("#pass").is(':checked')){
		//agency = 1;
		//alert(agency);
			  $("#passcheck").show();
			} else {
				//agency = 0;
		//alert(agency);
				 $("#passcheck").hide();
		}
		});
	
});
</script>
<style>
#errmsg
{
 color:red;
}

.error-message {
    color: #ff3c41;
    padding: 5px 10px;
    margin-left: 0;
    width: 100%;
}
</style>