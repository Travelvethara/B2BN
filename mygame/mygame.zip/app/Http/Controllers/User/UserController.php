<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\URL;

class UserController extends Controller
{
    //

   use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
   
	public function index()
    {
		if (Auth::check()){
		//check data
		$data['user'] = '';
		$role=DB::table('role_list')->orderBy('role_list.updated_at', 'DESC')->get();
		$agency=DB::table('agency')->orderBy('agency.updated_at', 'DESC')->get();
		if(isset($_GET['id']) && !empty($_GET['id']))
		{
		  $products=DB::table('userinformation')->where('id','=',''.$_GET['id'].'')->get();
		  $data['user'] = $products[0];
		}
        return view('user.user',$data,compact('role', 'agency'));
		}
		else
		{
		return redirect('/');
		}
    }

	//Users details Insert
	public function userinsert(Request $request)
	{
		$validator = $this->validate($request,[
		   'name' => 'required|string|max:255',
		   'email' => 'required|email|unique:users',
		   'password' => 'required|string|min:6|confirmed',
		   'phone' => 'required',
		   'mobile' => 'required',
		]);
	
		if ($validator) {
	    $insert['name'] = $request->input('name');
		$insert['email'] = $request->input('email');
		$insert['password'] = Hash::make($request->input('password'));
		$insert['RoleID'] = '3';
		$insert['user_type'] = 'UserInfo';
		$insert['activestatus'] = '0';
		$insert['created_at'] = date('Y-m-d H:i:s');
        $insert['updated_at'] = date('Y-m-d H:i:s');
		

		$lastInsertedID = DB::table('users')->insertGetId( $insert );
		
			
		//User details 
		$userdata['name'] = $request->input('name');
		$userdata['loginid'] = $lastInsertedID;
        $userdata['userid'] = 'USER1000'.$lastInsertedID;
		$userdata['email'] = $request->input('email');
		$userdata['phone'] = $request->input('phone');
		$userdata['mobile'] = $request->input('mobile');
		$userdata['roleid'] = $request->input('roleid');
		$userdata['agentid'] =  $request->input('agentid');
		$userdata['agent_level'] = '1';
		$userdata['activestatus'] = '0';
		$userdata['created_at'] = date('Y-m-d H:i:s');
        $userdata['updated_at'] = date('Y-m-d H:i:s');
		
	    
		
		$userInsertID = DB::table('userinformation')->insertGetId( $userdata );
		return redirect()->route('user', ['id' => $userInsertID]);
		
		}
		
		
	}

  //User details Update
public function userupdate(Request $request)
	{
		$id = $request->input('id');
		
		$role_details = '';
		$role=DB::table('role_list')->orderBy('role_list.updated_at', 'DESC')->get();
		$agency=DB::table('agency')->orderBy('agency.updated_at', 'DESC')->get();
		$role_details = DB::table('userinformation')->where('id', '=', $id)->get();
	     return view('user.userupdate', ['user' => $role_details[0],'role'=>$role, 'agency'=>$agency]);
		
	
	}
	
public function userupdatemodify(Request $request)
	{
		$id = $request->input('userid');
		
		$mobile = $request->input('mobile');
		echo $id,$mobile;
	
	$role=DB::table('role_list')->orderBy('role_list.updated_at', 'DESC')->get();
		$agency=DB::table('agency')->orderBy('agency.updated_at', 'DESC')->get();
		//exit;
		//$role = DB::table('userinformation')->where('id', '=', $id)->get();



$validator = $this->validate($request,[
     'name' => 'required|string|max:255',
     'email' => 'required|email',
     'phone' => 'required',
     'mobile' => 'required',
     'roleid' => 'required',
    'agentid' => 'required',
    
     
  ]);
  if ($request->input('userid')) {
	
	
	
   $lastInsertedID = DB::table('userinformation')->where('id', $request->input('userid'))->update([
   'name'=>$request->input('name'),'email'=>$request->input('email'),'phone'=>$request->input('phone'),'mobile'=>$request->input('mobile'),'roleid'=>$request->input('roleid'),'agentid'=>$request->input('agentid'),]);
   //Users table value update
  
   //echo $lastupdatedID;
  // exit;
   $users = DB::table('users')->where('id', $request->input('loginid'))->update(['name'=>$request->input('name'),'email'=>$request->input('email'),]);
   
    $lastupdatedID = DB::table('userinformation')->where('id', $request->input('userid'))->get();
  }
 	 return view('user.userupdate', ['user' => $lastupdatedID[0],'role'=>$role, 'agency'=>$agency]);
	
	}	
	
	
	 
	 
	 
	 
	 
    public function userlist(){
		
		//$products = DB::table('userinformation')->orderBy('userinformation.updated_at', 'DESC')->get();
		
		$products = DB::table('userinformation')
->select('userinformation.id','userinformation.name','userinformation.roleid','userinformation.userid','userinformation.activestatus','role_list.role_name')
->join('role_list','role_list.id','=','userinformation.roleid')
->orderBy('userinformation.updated_at', 'DESC')
->get();
$data['products'] = $products;
        return view('user.userlist',$data);	
		
			
   }
   
   
   public function userdelete(Request $request){
	   
   $id = $request->input('id');
   echo $id;
   exit;
   }
   
   
   




}


