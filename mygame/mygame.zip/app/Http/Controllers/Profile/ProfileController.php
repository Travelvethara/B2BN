<?php

namespace App\Http\Controllers\Profile;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\URL;

class ProfileController extends Controller
{
    //
	public function index()
    {
		
		
		
		
		if (Auth::check()){
			$Loginid = Auth::user()->id;
		 $data['CAgencyDetails'] = '';
		 if(Auth::user()->user_type == 'AgencyManger'){

		   $CAgencydetails =DB::table('agency')->where('loginid','=',''.$Loginid.'')->get();
		  
		   $data['name'] = $CAgencydetails[0]->name;
		   $data['email'] = $CAgencydetails[0]->email;
		   $data['phone'] = $CAgencydetails[0]->phone;
		   $data['userid'] = $CAgencydetails[0]->userid;
		   $data['id'] = $CAgencydetails[0]->id;
		   $data['loginid'] = $Loginid;
		   $data['type'] = 'AgencyManger';
		   
		 }
           return view('profile.profile',$data);
		}
		else
		{
		   return redirect('/');
		}
		
    }
	
	public function profileupdate(Request $request){
		
		
		$validator = $this->validate($request,[
		   'name' => 'required|string|max:255',
		   'email' => 'required|email|',
		   'phone' => 'required',

		]);
		if($request->input('changepassword')){
		$validator1 = $this->validate($request,[

		   'password' => 'required|string|min:6|confirmed',
		]);
		}
		
		if($validator){
			
			
			
			
			
			if($request->input('type') == 'AgencyManger'){
				
		 $lastInsertedID = DB::table('agency')->where('id', $request->input('id'))->update(['name' => $request->input('name'),'email' => $request->input('email'),'phone' => $request->input('phone')]);
             
			 
			   $password = Hash::make($request->input('password'));
				$users = DB::table('users')->where('id', $request->input('loginid'))->update(['email' => $request->input('email')]);
				if($request->input('changepassword')){
					$users = DB::table('users')->where('id', $request->input('loginid'))->update(['email' => $request->input('email'),'password' => $password]);
				}
				
			}
			
		}
		
		return redirect()->route('profile');
		
		
		
		
	}
	
	
	
	
	
}
