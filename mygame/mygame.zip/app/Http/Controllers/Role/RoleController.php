<?php

namespace App\Http\Controllers\Role;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\URL;

class RoleController extends Controller
{
    //
	
	public function index()
    {
		if (Auth::check()){
			
		$data['rolelist'] = '';
		if(isset($_GET['id']) && !empty($_GET['id']))
		{
		  $products=DB::table('role_list')->where('id','=',''.$_GET['id'].'')->get();
		  $data['rolelist'] = $products[0];
		}	
           return view('role.role',$data);
		}
		else
		{
		   return redirect('/');
		}
    }
	
	
	public function rolelist()
    {
		if (Auth::check()){
			
		$data['rolelist'] = '';
		
		  $products=DB::table('role_list')->where('checkstatus','=','0')->get();
		  
		  
		 $UserList = array();
		  $i=1;
		  foreach($products as $products_val){
			  $pid = 2;
		  $Userid=DB::table('users')->where('RoleID','=',$pid)->where('activestatus','=','1')->get();
		  $UserList[$Userid[0]->RoleID][$i] = $Userid[0]->RoleID;
		   
		  ++$i;
		  }
		  $data['rolelist'] = $products;
		  $data['rolelistcount'] = $UserList;
			
           return view('role.rolelist',$data);
		}
		else
		{
		   return redirect('/');
		}
    }
	
	
	public function roleinsert(Request $request)
    {
		
		$validator = $this->validate($request,[
		   'role_name' => 'required|string|max:255|unique:role_list',
		]);
		if ($validator) {
	     $insertdata['role_name'] = $request->input('role_name');
		 $insertdata['agency_create_user'] = 0; if($request->input('agency_create_user')){ $insertdata['agency_create_user'] = 1;   }
			$insertdata['agency_approve'] = 0; if($request->input('agency_approve')){ $insertdata['agency_approve'] = 1;   }
			$insertdata['agency_open'] = 0; if($request->input('agency_open')){ $insertdata['agency_open'] = 1;   }
			$insertdata['agency_remove'] = 0; if($request->input('agency_remove')){ $insertdata['agency_remove'] = 1;   }
			$insertdata['agency_lock'] = 0; if($request->input('agency_lock')){ $insertdata['agency_lock'] = 1;   }
			$insertdata['user_create'] = 0; if($request->input('user_create')){ $insertdata['user_create'] = 1;   }
			$insertdata['user_remove'] = 0; if($request->input('user_remove')){ $insertdata['user_remove'] = 1;   }
			$insertdata['user_lock'] = 0; if($request->input('user_lock')){ $insertdata['user_lock'] = 1;   }
			$insertdata['approve_credit_limit'] = 0; if($request->input('approve_credit_limit')){ $insertdata['approve_credit_limit'] = 1;   }
			$insertdata['approve_credit_terms'] = 0; if($request->input('approve_credit_terms')){ $insertdata['approve_credit_terms'] = 1;   }
			$insertdata['approve_credit_assign'] = 0; if($request->input('approve_credit_assign')){ $insertdata['approve_credit_assign'] = 1;   }
			$insertdata['approve_credit_assign_terms'] = 0; if($request->input('approve_credit_assign_terms')){ $insertdata['approve_credit_assign_terms'] = 1;   }
            $insertdata['book'] = 0; if($request->input('book')){ $insertdata['book'] = 1;   }
			$insertdata['offline_booking'] = 0; if($request->input('offline_booking')){ $insertdata['offline_booking'] = 1;   }
			$insertdata['booking_confirm'] = 0; if($request->input('booking_confirm')){ $insertdata['booking_confirm'] = 1;   }
			$insertdata['create_voucher'] = 0; if($request->input('create_voucher')){ $insertdata['create_voucher'] = 1;   }
			$insertdata['issue_receipts'] = 0; if($request->input('issue_receipts')){ $insertdata['issue_receipts'] = 1;   }
			$insertdata['knock_off'] = 0; if($request->input('knock_off')){ $insertdata['knock_off'] = 1;   }
			$insertdata['incentive_slobs'] = 0; if($request->input('incentive_slobs')){ $insertdata['incentive_slobs'] = 1;   }
			$insertdata['partial_refund_cancel'] = 0; if($request->input('partial_refund_cancel')){ $insertdata['partial_refund_cancel'] = 1;   }
			$insertdata['approve_refund_cancel'] = 0; if($request->input('approve_refund_cancel')){ $insertdata['approve_refund_cancel'] = 1;   }
		
			
			$roleId = DB::table('role_list')->insertGetId( $insertdata );
			return redirect()->route('rolelist');
		 exit;
		
		}
	}
	
	
	public function roleupdate(Request $request)
    {
		
		
		$validator = $this->validate($request,[
		   'role_name' => 'required|string|max:255',
		]);
		if ($validator) {
		    $updatedata['role_name'] = $request->input('role_name');
		    $updatedata['agency_create_user'] = 0; if($request->input('agency_create_user')){ $updatedata['agency_create_user'] = 1;   }
			$updatedata['agency_approve'] = 0; if($request->input('agency_approve')){ $updatedata['agency_approve'] = 1;   }
			$updatedata['agency_open'] = 0; if($request->input('agency_open')){ $updatedata['agency_open'] = 1;   }
			$updatedata['agency_remove'] = 0; if($request->input('agency_remove')){ $updatedata['agency_remove'] = 1;   }
			$updatedata['agency_lock'] = 0; if($request->input('agency_lock')){ $updatedata['agency_lock'] = 1;   }
			$updatedata['user_create'] = 0; if($request->input('user_create')){ $updatedata['user_create'] = 1;   }
			$updatedata['user_remove'] = 0; if($request->input('user_remove')){ $updatedata['user_remove'] = 1;   }
			$updatedata['user_lock'] = 0; if($request->input('user_lock')){ $updatedata['user_lock'] = 1;   }
			$updatedata['approve_credit_limit'] = 0; if($request->input('approve_credit_limit')){ $updatedata['approve_credit_limit'] = 1;   }
			$updatedata['approve_credit_terms'] = 0; if($request->input('approve_credit_terms')){ $updatedata['approve_credit_terms'] = 1;   }
			$updatedata['approve_credit_assign'] = 0; if($request->input('approve_credit_assign')){ $updatedata['approve_credit_assign'] = 1;   }
			$updatedata['approve_credit_assign_terms'] = 0; if($request->input('approve_credit_assign_terms')){ $updatedata['approve_credit_assign_terms'] = 1;   }
            $updatedata['book'] = 0; if($request->input('book')){ $updatedata['book'] = 1;   }
			$updatedata['offline_booking'] = 0; if($request->input('offline_booking')){ $updatedata['offline_booking'] = 1;   }
			$updatedata['booking_confirm'] = 0; if($request->input('booking_confirm')){ $updatedata['booking_confirm'] = 1;   }
			$updatedata['create_voucher'] = 0; if($request->input('create_voucher')){ $updatedata['create_voucher'] = 1;   }
			$updatedata['issue_receipts'] = 0; if($request->input('issue_receipts')){ $updatedata['issue_receipts'] = 1;   }
			$updatedata['knock_off'] = 0; if($request->input('knock_off')){ $updatedata['knock_off'] = 1;   }
			$updatedata['incentive_slobs'] = 0; if($request->input('incentive_slobs')){ $updatedata['incentive_slobs'] = 1;   }
			$updatedata['partial_refund_cancel'] = 0; if($request->input('partial_refund_cancel')){ $updatedata['partial_refund_cancel'] = 1;   }
			$updatedata['approve_refund_cancel'] = 0; if($request->input('approve_refund_cancel')){ $updatedata['approve_refund_cancel'] = 1;   }
			
			$lastInsertedID = DB::table('role_list')->where('id', $request->input('roleid'))->update(['role_name' => $updatedata['role_name'],'agency_create_user' => $updatedata['agency_create_user'],'agency_approve' => $updatedata['agency_approve'],'agency_open' => $updatedata['agency_open'],'agency_remove' => $updatedata['agency_remove'],'agency_lock' => $updatedata['agency_lock'],'user_create' => $updatedata['user_create'],'user_remove' => $updatedata['user_remove'],'user_lock' => $updatedata['user_lock'],'approve_credit_limit' => $updatedata['approve_credit_limit'],'approve_credit_terms' => $updatedata['approve_credit_terms'],'approve_credit_assign' => $updatedata['approve_credit_assign'],'approve_credit_assign_terms' => $updatedata['approve_credit_assign_terms'],'book' => $updatedata['book'],'offline_booking' => $updatedata['offline_booking'],'booking_confirm' => $updatedata['booking_confirm'],'create_voucher' => $updatedata['create_voucher'],'issue_receipts' => $updatedata['issue_receipts'],
'knock_off' => $updatedata['knock_off'],'incentive_slobs' => $updatedata['incentive_slobs'],'partial_refund_cancel' => $updatedata['partial_refund_cancel'],
'approve_refund_cancel' => $updatedata['approve_refund_cancel']]);


         return redirect()->route('rolelist');
			
			
			
			
			
			
			
			
			
				
			
			
		}
		
		
	}
	
	public function RoleDelete(Request $request)
    {
		$id = $request->input('id');
		
		$del = DB::table('role_list')->where('id', '=', $id)->delete();
		return redirect()->route('rolelist');
	}
	
	
	
	
}
