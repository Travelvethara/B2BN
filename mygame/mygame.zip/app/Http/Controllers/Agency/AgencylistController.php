<?php

namespace App\Http\Controllers\Agency;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\URL;

class AgencylistController extends Controller
{
	public function __construct()
    {
        //$this->middleware('auth');
    }
	
    public function index(){
		$products = DB::table('agency')->orderBy('agency.updated_at', 'DESC')->offset(0)->limit(10)->get();
		$data['products'] = $products;
        return view('agency.agencyList',$data);		
   }
   
    public function agencyListLoadMore(Request $request){
		$offset = $request->input('offset');
		$parentagency = $request->input('parentagency');
		$subagency = $request->input('subagency');
		
		
		$products=DB::table('agency')->orderBy('agency.updated_at', 'DESC')->offset($offset)->limit(10);

		
		if($parentagency == 1 && $subagency == 1) {
			$result = $products->get();
			}
			
		if($parentagency == 1 && $subagency == 0) {
			$result = $products->where('parentagencyid', '<=', 0)->get();
			}	
		if($parentagency == 0 && $subagency == 1) {
			$result = $products->where('parentagencyid', '>', 0)->get();
			}	
		if($parentagency == 0 && $subagency == 0) {
			$result = $products->get();
			}	
       	echo json_encode($result);
		exit;
   }
}
