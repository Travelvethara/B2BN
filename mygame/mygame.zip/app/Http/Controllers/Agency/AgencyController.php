<?php

namespace App\Http\Controllers\Agency;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\URL;

class AgencyController extends Controller
{
    //

   use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
   
	public function index()
    {
		if (Auth::check()){
		//check data
		$data['agency'] = '';
		$data['CheckAgency'] = '';
		$data['CAgencyDetails'] = '';
		$RoleId = Auth::user()->RoleID;
		$Loginid = Auth::user()->id;
		if(Auth::user()->user_type == 'AgencyManger'){
		$RoleIdPremissions =DB::table('role_list')->where('id','=',''.$RoleId.'')->get();
		$CAgencydetails =DB::table('agency')->where('loginid','=',''.$Loginid.'')->get();
		$data['CAgencyDetails'] = $CAgencydetails[0]; 
		$data['CheckAgency'] = $RoleIdPremissions[0];
		}
		
		
		if(isset($_GET['id']) && !empty($_GET['id']))
		{
		  $products=DB::table('agency')->where('id','=',''.$_GET['id'].'')->get();
		  $data['agency'] = $products[0];
		}	
        return view('agency.agency',$data);
		}
		else
		{
		return redirect('/');
		}
		
    }
	
	public function agencystore(Request $request)
    {
		
		$validator = $this->validate($request,[
		   'name' => 'required|string|max:255',
		   'email' => 'required|email|unique:users',
		   'phone' => 'required',
		   'password' => 'required|string|min:6|confirmed',
		   'phone' => 'required',
		   'mobile' => 'required',
		   'whatsapp' => 'required',
		]);

		if ($validator) {
		$insertdata['name'] = $request->input('name');
		$insertdata['email'] = $request->input('email');
		$insertdata['password'] = Hash::make($request->input('password'));
		$insertdata['RoleID'] = '2';
		$insertdata['user_type'] = 'AgencyManger';
		$insertdata['activestatus'] = '0';
		$lastInsertedID = DB::table('users')->insertGetId( $insertdata );
		//user agency add 
		$agencyInsert['name'] = $request->input('name');
		$agencyInsert['loginid'] = $lastInsertedID;
		$UserId = 'AGN100'.$lastInsertedID; if($request->input('parentid')){ $UserId = 'AGNSUB100'.$lastInsertedID;   }
		$agencyInsert['userid'] = $UserId;
		$agencyInsert['email'] = $request->input('email');
		$agencyInsert['phone'] = $request->input('phone');
		$agencyInsert['mobile'] = $request->input('mobile');
		$agencyInsert['whatapp'] = $request->input('whatsapp');
		$parentid = 0; if($request->input('parentid')){ $parentid = $request->input('parentid');   }
		$agencyInsert['parentagencyid'] = $parentid;
		$agencyInsert['address1'] = '';
		$agencyInsert['address2'] = '';
		$agencyInsert['country'] = '';
		$agencyInsert['city'] = '';
		$agencyInsert['pcode'] = '';
		$agencyInsert['skype'] = '';
		$agencyInsert['website'] = '';
		$agencyInsert['rnumber'] = '';
		$agencyInsert['aname'] = '';
		$agencyInsert['aemail'] = '';
		$agencyInsert['amobile'] = '';
		$agencyInsert['aphone'] = '';
		$agencyInsert['awhatsapp'] = '';
		$agencyInsert['created_at'] = date('Y-m-d H:i:s');
        $agencyInsert['updated_at'] = date('Y-m-d H:i:s');
		
		$agencyInsertID = DB::table('agency')->insertGetId( $agencyInsert );
		return redirect()->route('agency', ['id' => $agencyInsertID,'tab' => '2']);
		
        }

	
	}
	
	
	//upadte
	
	
	public function agencyupdate(Request $request)
    {
      $validator = $this->validate($request,[
		   'name' => 'required|string|max:255',
		   'email' => 'required|email',
		   'phone' => 'required',
		   'mobile' => 'required',
		   'whatsapp' => 'required',
		]);
		
		if ($request->input('agencyid')) {
			
			$lastInsertedID = DB::table('agency')->where('id', $request->input('agencyid'))->update(['name' => $request->input('name'),'email' => $request->input('email'),'phone' => $request->input('phone'),'mobile' => $request->input('mobile'),'whatapp' => $request->input('whatsapp'),]);
			$users = DB::table('users')->where('id', $request->input('loginid'))->update(['email' => $request->input('email')]);
			
		}
		
		return redirect()->route('agency', ['id' => $request->input('agencyid'),'tab' => '1']);


	
	}
	
	public function viewagency(Request $request){
		
		$id = $request->input('id');
		$role_type = Auth::user()->user_type;
		$products=DB::table('agency')->where('id','=',''.$id.'')->get();
		$count = $products->count();
		
		$data['agency'] = $products[0];
		$data['role_type'] = $role_type;
        return view('agency.viewagency',$data);
		
		}
	public function updateagency(Request $request){
		

			if(Auth::user()->user_type == 'AgencyManger') 
			{
				
				$validator = $this->validate($request,[
				   'newcreditlimit' => 'required',
				]);
		
				$update['newcreditlimit'] = $request->input('newcreditlimit');
				$update['requested_by'] = Auth::user()->id;
				$update['id'] = $request->input('id');
				
				$lastInsertedID = DB::table('agency')->where('id', $update['id'])->update(['requested_amount' => $update['newcreditlimit'],'requested_by' => $update['requested_by']]);
				
				return redirect()->route('agency.viewagency', ['id' => $request->input('id')]);
				}
				
			if(Auth::user()->user_type == 'SuperAdmin') 
			{
				
				$update['newcreditlimit'] = $request->input('newcreditlimit');
				$update['requestedstatus'] = $request->input('requestedstatus');
				$update['id'] = $request->input('id');
				
				$update['newmarkup'] = $request->input('newmarkup');
				
				$currentprice = DB::table('agency')->where('id','=',''.$update['id'].'')->get();
				
				$newcreditlimit = $currentprice[0]->current_credit_limit + $update['newcreditlimit'];
				
				if($request->input('activestatus') && $request->input('activestatus') == 'on'){
					$activestatus = 1;
					} else {
						$activestatus = 0;
						}
				
				$lastInsertedID = DB::table('agency')->where('id', $update['id'])->update(['requested_amount' => '0','requested_by' => '0', 'current_credit_limit' => $newcreditlimit, 'activestatus' => $activestatus ]);
				
				if($update['newmarkup'] > 0) { 
					$lastInsertedID = DB::table('agency')->where('id', $update['id'])->update(['current_markup' => $update['newmarkup']]);
				}
				
					$lastInsertedID = DB::table('users')->where('id', $currentprice[0]->loginid)->update(['activestatus' => $activestatus]);
				
				return redirect()->route('agency.viewagency', ['id' => $request->input('id')]);
				}	
			
		
		}
		
	public function agencymanager(Request $request)
    {
	
      $validator = $this->validate($request,[
		   'aname' => 'required|string|max:255',
		   'aemail' => 'required|email',
		   'address1' => 'required',
		   'address2' => 'required',
		   'country' => 'required',
		   'city' => 'required',
		   'zip' => 'required',
		   'amobile' => 'required',
		   'aphone' => 'required',
		   'awhatsapp' => 'required',
		   'skype' => 'required',
		   'website' => 'required',
		   'register_number' =>'required',
		   
		]);
	
	if ($request->input('agency_id')) {
			
			$lastInsertedID = DB::table('agency')->where('id', $request->input('agency_id'))->update(['aname' => $request->input('aname'),'aemail' => $request->input('aemail'),'address1' => $request->input('address1'),'address2' => $request->input('address2'),'country' => $request->input('country'),'city' => $request->input('city'),'pcode' => $request->input('zip'),'amobile' => $request->input('amobile'),'aphone' => $request->input('aphone'),'awhatsapp' => $request->input('awhatsapp'),'skype' => $request->input('skype'),'website' => $request->input('website'),'rnumber' => $request->input('register_number')]);
		}
		
		return redirect()->route('agency', ['id' => $request->input('agency_id'),'tab' => '2']);	
		
		
		
	}
	
	
	protected function create(array $data)
    {
        
    }




}


