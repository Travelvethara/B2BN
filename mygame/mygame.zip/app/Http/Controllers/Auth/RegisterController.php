<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\URL;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    

    /**
     * Create a new controller instance.
     *
     * @return void
     */


    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */

	
	public function agencyregister(Request $request)
    {
		$validator = $this->validate($request,[
		   'name' => 'required|string|max:255',
		   'email' => 'required|email|unique:users',
		   'phone' => 'required',
		   'password' => 'required|string|min:6|confirmed',
		   'phone' => 'required',
		   'mobile' => 'required',
		   'whatsapp' => 'required',
		   'aname' => 'required|string|max:255',
		   'aemail' => 'required|email',
		   'address1' => 'required',
		   'address2' => 'required',
		   'country' => 'required',
		   'city' => 'required',
		   'zip' => 'required',
		   'amobile' => 'required',
		   'aphone' => 'required',
		   'awhatsapp' => 'required',
		   'skype' => 'required',
		   'website' => 'required',
		   'register_number' =>'required',
		]);
		
		
		if ($validator) {
		$insertdata['name'] = $request->input('name');
		$insertdata['email'] = $request->input('email');
		$insertdata['password'] = Hash::make($request->input('password'));
		$insertdata['RoleID'] = '0';
		$insertdata['activestatus'] = '0';
		$insertdata['user_type'] = '';
		$lastInsertedID = DB::table('users')->insertGetId( $insertdata );
		//user agency add 
		$agencyInsert['name'] = $request->input('name');
		$agencyInsert['loginid'] = $lastInsertedID;
		$agencyInsert['userid'] = 'AGN100'.$lastInsertedID;
		$agencyInsert['email'] = $request->input('email');
		$agencyInsert['phone'] = $request->input('phone');
		$agencyInsert['mobile'] = $request->input('mobile');
		$agencyInsert['whatapp'] = $request->input('whatsapp');
		$agencyInsert['address1'] = $request->input('address1');
		$agencyInsert['address2'] = $request->input('address2');
		$agencyInsert['country'] = $request->input('country');
		$agencyInsert['city'] = $request->input('city');
		$agencyInsert['pcode'] = $request->input('zip');
		$agencyInsert['skype'] = $request->input('skype');
		$agencyInsert['website'] = $request->input('website');
		$agencyInsert['rnumber'] = $request->input('register_number');
		$agencyInsert['aname'] = $request->input('aname');
		$agencyInsert['aemail'] = $request->input('aemail');
		$agencyInsert['amobile'] = $request->input('amobile');
		$agencyInsert['aphone'] = $request->input('aphone');
		$agencyInsert['awhatsapp'] = $request->input('awhatsapp');

		
		$agencyInsertID = DB::table('agency')->insertGetId( $agencyInsert );
		
		return redirect('/');
		
        }
		

		
		
		
		
	}
	
	
}
