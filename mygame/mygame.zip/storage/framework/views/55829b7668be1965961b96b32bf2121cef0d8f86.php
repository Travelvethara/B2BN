<?php $__env->startSection('content'); ?>

<?php

$route = 'agencylist.agencydetails';

$data ='';

?>
<!-- END: Left Aside -->
				<div class="m-grid__item m-grid__item--fluid m-wrapper">
					<!-- BEGIN: Subheader -->
					<div class="m-subheader ">
						<div class="d-flex align-items-center">
							<div class="mr-auto">
								<h3 class="m-subheader__title ">
									Agencies List
								</h3>
							</div>
						</div>
					</div>
					<!-- END: Subheader -->
					<div class="m-content agencies_list">
						<div class="m-portlet m-portlet-padding agency-info-tab">
						<div class="parent-sub-agencies">
							<div class="parent-checkbox">
							    <label class="m-checkbox">
									<input type="checkbox" id="parentagency" checked="checked"> <b>Parent Agency</b>
									<span></span>
								</label>
							</div>
							<div class="parent-checkbox">
							     <label class="m-checkbox">
									<input type="checkbox" id="subagency" checked="checked"> <b>Sub Agency</b>
									<span></span>
								</label>
							</div>
						</div>
						   <div class="data-table-block">
								<table class="table table-striped" id="moreresults">
										<thead>
										  <tr>
                                            <th>S No</th>
											<th>Agency Name 
											   <i class="fas fa-sort-down datatable-down-ar"></i>
												<i class="fas fa-sort-up datatable-up-ar"></i>
											</th>
											<th>Agency level
											    <i class="fas fa-sort-down datatable-down-ar"></i>
												<i class="fas fa-sort-up datatable-up-ar"></i>
											</th>
											<th>Login Email ID
											   <i class="fas fa-sort-down datatable-down-ar"></i>
												<i class="fas fa-sort-up datatable-up-ar"></i>
											</th>
											<th>City
											  <i class="fas fa-sort-down datatable-down-ar"></i>
												<i class="fas fa-sort-up datatable-up-ar"></i>
											</th>
											<th>Country
											 
											</th>
											<th>Status
											  
											</th>
											<th>Action
                                          
											 
											</th>
										  </tr>
										</thead>
										<tbody id="tablebody">
                                        <?php $i =1; ?>
                                         <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                               <td><?php echo e($i); ?></td>
                                               <td><?php echo e($details->name); ?></td>
                                               <td><?php if(isset($details->parentagencyid) && ($details->parentagencyid < 1)) { ?>Parent<?php
                               } else { ?> Sub <?php } ?></td>
                                               <td><?php echo e($details->email); ?></td>
                                               <td><?php echo e($details->city); ?></td>
                                               <td><?php echo e($details->country); ?></td>
                                               <td><?php if(isset($details->activestatus) && ($details->activestatus != 0)) { ?> Active <?php
                               } else { ?> Locked <?php } ?> </td>
                               					<td>
                                                    <i class="fas fa-eye" data-id="1"></i>
													<a href="<?php echo e(route('agency')); ?>?id=<?php echo e($details->id); ?>" target="_blank"><i class="fas fa-edit"></i></a>
													<i class="far fa-trash-alt"></i>
                               					</td>
                                               </tr>    
                                         <?php $i++; ?>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     
                                    <div id="">
                                    </div>    
									</tbody>
								</table>
						   </div>
                        </div>
                   </div>
                   <input type="hidden" id="autoincrementid" value="<?php echo $i; ?>"/>
                   <input type="hidden" id="offset" value="10" />
                   <?php if($i > 10) { ?>
                   <div class="loadmorebutton">
                   <button type="submit" id="loadMore">Load More</button>	
                   </div>
                   <?php } ?>			
				</div>
                
			
			
			<!-- end:: Body -->
            <!-- begin::Footer -->
            
            <?php $__env->stopSection(); ?>
            
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>

$(document).ready(function () {
function checkParentCheckboxValue() {
	var parentagency ='';
	
		if($("#parentagency").is(':checked')){
			parentagency = 1;
			} else {
				parentagency = 0;
		}
	return parentagency;	
	}
	
function checkSubCheckboxValue() {
	var subagency ='';
	if($("#subagency").is(':checked')){
			subagency = 1;
			} else {
				subagency = 0;
				}	
	return subagency;	
	}
	
function append_data(d) {
	 var one = '';
	 
	 var last_id =	parseInt($("#autoincrementid").val());
	 last_id--;	
	 var greaterthenzero = '';
	 greaterthenzero = 1;
	 $.map( d, function( a ) {
		 var parent = '';
		 var status = '';
		 ida = a.parentagencyid;
		 if(!ida){
			 var namee = 'Parent';
			 }
			 else{
				 var namee = 'Sub';
			 }
			 
			 status =a.activestatus;
			 if(status>0){
				  var  statu = 'Active';
			 }
			 else{
				 var statu = 'Locked';
				 
			 }
		 last_id++;	
		 greaterthenzero++; 
		 
		 var editicon = '<a href="<?php echo route('agency'); ?>?id='+a.id+'" target="_blank"><i class="fas fa-edit"></i></a>';
		 
		 one += '<tr><td>'+last_id+'</td><td>'+a.name+'</td><td>'+namee+'</td><td>'+a.email+'</td><td>'+a.city+'</td><td>'+a.country+'</td><td>'+statu+'</td><td><i class="fas fa-eye"></i>'+editicon+'<i class="far fa-trash-alt"></i></td></tr>';
	 });
	 console.log(greaterthenzero);
	 if(parseInt(greaterthenzero) < 10) {
		   $(".loadmorebutton").hide();
		 } else {
			$(".loadmorebutton").show(); 
			 }
	 $("#autoincrementid").val(last_id);
	 return one;
	}
	
function AjaxCall(offset, parentagency, subagency){
	console.log(offset);
			$.ajax
			({
			  type: "GET",
			  url: "agencylistLoadMoreAjax",
			  data: {'offset': offset, 'parentagency': parentagency, 'subagency':subagency },
			  success: function(data)
			  {
				 data= JSON.parse(data);
				 var result = append_data(data);
				 $("#moreresults").append(result);
			  }
			});
	}
		
$(document).on('click', '#parentagency', function(){
	    $("#autoincrementid").val('1');
		var offset = 0;
		$('#offset').val('10'); 
		parentagency = checkParentCheckboxValue();
		subagency = checkSubCheckboxValue();
		$("#tablebody").html('');
		AjaxCall(offset, parentagency, subagency);
});


$(document).on('click', '#subagency', function(){
	    $("#autoincrementid").val('1');
		var offset = 0;
		$('#offset').val('10'); 
		parentagency = checkParentCheckboxValue();
		subagency = checkSubCheckboxValue();
		$("#tablebody").html('')
		AjaxCall(offset, parentagency, subagency);
});


$(document).on('click', '#loadMore', function(){
		var offset = '';
		offset = $("#offset").val();
		
		var newoffset = '';
		newoffset = parseInt(offset) + parseInt(10);

		$('#offset').val(newoffset); 

		var parentagency = subagency = '';

		parentagency = checkParentCheckboxValue();
		subagency = checkSubCheckboxValue();
		AjaxCall(offset, parentagency, subagency);
			
    });
   
});

$(document).on('click', '.fa-eye', function(){
	    console.log('Hii');
		console.log($(this).data('id'));
});
</script>


<?php echo $__env->make('./layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>