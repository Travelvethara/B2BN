<?php $__env->startSection('content'); ?>
<?php 
$route = 'agency.agencystore';
if (isset($agency) && !empty($agency)){
$route = 'agency.agencyupdate';
}
//active tab
$activetab = 'active show';

$activecon = 'active';

$activecon2 = '';

$activetab2 = '';

if(isset($_GET['id']) && !empty($_GET['id'])){
	if(isset($_GET['tab']) && !empty($_GET['tab'])){
	
		if($_GET['tab'] == 1){
			$activetab = 'active show';
			$activecon = 'active';
		}
		if($_GET['tab'] == 2){
			$activetab= '';
			$activecon = '';
			$activecon2 = 'active';
			$activetab2 = 'active show';
		
		}
	}

}

?>



	<!-- END: Left Aside -->
				<div class="m-grid__item m-grid__item--fluid m-wrapper">
					<!-- BEGIN: Subheader -->
					<div class="m-subheader ">
						<div class="d-flex align-items-center">
							<div class="mr-auto">
								<h3 class="m-subheader__title ">
                                <?php if(Auth::user()->user_type == 'AgencyManger'){ ?>
									   Create Sub Agency
                                    <?php } else if(Auth::user()->user_type == 'SuperAdmin'){ ?>
                                       Create Agency
                                    <?php } ?>
								</h3>
							</div>
						</div>
					</div>
					<!-- END: Subheader -->
					<div class="m-content">
						<!--Begin::Section-->
						<div class="row">
							<ul class="nav nav-tabs  m-tabs-line m-tabs-line--primary" role="tablist">
											<li class="nav-item m-tabs__item">
												<a class="nav-link m-tabs__link managerdetails <?php echo e($activetab); ?>" data-toggle="tab" href="#m_tabs_6_1" role="tab" aria-selected="false">
                                                    Manager Details
												</a>
											</li>
									<?php if(isset($_GET['id']) && !empty($_GET['id'])){?>
											<li class="nav-item m-tabs__item">
												<a class="nav-link m-tabs__link agencyinfo <?php echo e($activetab2); ?>" data-toggle="tab" href="#m_tabs_6_3" role="tab" aria-selected="true">
													Agency Information
												</a>
											</li>
                                            <?php } ?>
										</ul>
						</div>
                        <div class="tab-content">
											<div class="tab-pane <?php echo e($activecon); ?>" id="m_tabs_6_1" role="tabpanel">
								<form action="<?php echo e(route($route)); ?>" method="post">
                                    
                                  <input type="hidden" name="_token" value="<?php echo @csrf_token(); ?>">
                                  
												<div class="m-portlet m-portlet-padding agency-info-tab">
													<div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Name</label>
					<input type="text" name="name" class="form-control m-input m-input--square"  placeholder="Name" <?php if (isset($agency->name) && !empty($agency->name)){?> value="<?php echo e($agency->name); ?>" <?php }else{ ?>value="<?php echo e(old('name')); ?>"<?php } ?>>
                   	<span class="error-message">   <?php if($errors->has('name')): ?>
                       	  <?php echo e($errors->first('name')); ?>

                        <?php endif; ?>    </span>

															</div>
														</div>
														<div class="col-md-6 ">
															<div class="form-group m-form__group">
                                                            <label>Email</label>
					<input type="email" name="email" class="form-control m-input m-input--square"  aria-describedby="emailHelp" placeholder="Email" <?php if (isset($agency->email) && !empty($agency->email)){?> value="<?php echo e($agency->email); ?>" <?php }else{ ?>value="<?php echo e(old('email')); ?>"<?php } ?>>
                    	<span class="error-message">  <?php if($errors->has('email')): ?>
                       						  <?php echo e($errors->first('email')); ?>

                       							 <?php endif; ?> </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Phone</label>
					<input type="text" name="phone" id="phone" class="form-control m-input m-input--square" placeholder="Phone" <?php if (isset($agency->phone) && !empty($agency->phone)){?> value="<?php echo e($agency->phone); ?>" <?php }else{ ?>value="<?php echo e(old('phone')); ?>"<?php } ?>>
                    						<span class="error-message">  <?php if($errors->has('phone')): ?>
                       						  <?php echo e($errors->first('phone')); ?>

                       							 <?php endif; ?> </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Mobile</label>
					<input type="text" name="mobile" id="mobile" class="form-control m-input m-input--square"  placeholder="Mobile"  <?php if (isset($agency->mobile) && !empty($agency->mobile)){?> value="<?php echo e($agency->mobile); ?>" <?php }else{ ?>value="<?php echo e(old('mobile')); ?>"<?php } ?>>
                    							<span class="error-message">  <?php if($errors->has('mobile')): ?>
                       						  <?php echo e($errors->first('mobile')); ?>

                       							 <?php endif; ?> </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>whatsapp</label>
					<input type="text" name="whatsapp" id="whatsapp" class="form-control m-input m-input--square"  placeholder="whatsapp" <?php if (isset($agency->whatapp) && !empty($agency->whatapp)){?> value="<?php echo e($agency->whatapp); ?>" <?php }else{ ?>value="<?php echo e(old('whatsapp')); ?>"<?php } ?>>
                    							<span class="error-message">  <?php if($errors->has('whatsapp')): ?>
                       						  <?php echo e($errors->first('whatsapp')); ?>

                       							 <?php endif; ?> </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Auto</label>
					<input type="text" name="userid" class="form-control m-input m-input--square" readonly  placeholder="Auto" <?php if (isset($agency->userid) && !empty($agency->userid)){?> value="<?php echo e($agency->userid); ?>" <?php }else{ ?>value="<?php echo e(old('userid')); ?>"<?php } ?>>
                    					
															</div>
														</div>
												   </div>
                                  <?php if (empty($agency->loginid)){ ?>                 
												    <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>password</label>
					<input type="password" name="password" class="form-control m-input m-input--square" placeholder="Password" >
                    			<span class="error-message"> <?php if($errors->has('password')): ?>
                       						  <?php echo e($errors->first('password')); ?>

                       							 <?php endif; ?> </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>password_confirmation</label>
					<input type="password" name="password_confirmation" class="form-control m-input m-input--square"  placeholder="Confirm Password">
                    					
															</div>
														</div>
												   </div>
                                               <?php } ?>    
												   
												    <div class="row">
														<div class="col-md-6">
                                                        <?php if(isset($CAgencyDetails) && !empty($CAgencyDetails)){ ?>
                                                        <input type="hidden" name="parentid" value="<?php echo e($CAgencyDetails->id); ?>"/>
                                                        <?php } ?>
                                                             <?php if (!empty($agency->loginid)){  ?> 
															 <input type="hidden" name="loginid" value="<?php echo e($agency->loginid); ?>"/>
                                                             <input type="hidden" name="agencyid" value="<?php echo e($agency->id); ?>"/>
															 
															 <?php }  ?>
															<button type="submit" name="create_agencyy" class="btn btn-primary">Create Agency</button>
														</div>
													</div>
											</div>
											</div>
                                            </form>
                                            <!------- create agency---------->
											<div class="tab-pane <?php echo e($activecon2); ?>" id="m_tabs_6_3" role="tabpanel">
												<div class="m-portlet m-portlet-padding agency-info-tab">
                                 		<form action="<?php echo e(route('agency.agencymanager')); ?>" method="POST">
                                         <input type="hidden" name="_token" value="<?php echo @csrf_token(); ?>">
                                         <?php if (!empty($agency->loginid)){  ?> 
                                                <input type="hidden" name="agency_id" value="<?php echo e($agency->id); ?>"/>
										<?php }  ?>
													<div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Agency Name</label>
			<input type="text" class="form-control m-input m-input--square"  name="aname" id="aname" placeholder="Agency Name"<?php if (isset($agency->aname) && !empty($agency->aname)){?> value="<?php echo e($agency->aname); ?>" <?php }else{ ?>value="<?php echo e(old('aname')); ?>"<?php } ?>>
                            <span class="error-message">  <?php if($errors->has('aname')): ?>
                       						  <?php echo e($errors->first('aname')); ?>

                       							 <?php endif; ?> </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Email</label>
		<input type="email" class="form-control m-input m-input--square" name="aemail" id="aemail" aria-describedby="emailHelp" placeholder="Email" <?php if (isset($agency->aemail) && !empty($agency->aemail)){?> value="<?php echo e($agency->aemail); ?>" <?php }else{ ?>value="<?php echo e(old('aemail')); ?>"<?php } ?>>
                    <span class="error-message">  <?php if($errors->has('aemail')): ?>
                       						  <?php echo e($errors->first('aemail')); ?>

                       							 <?php endif; ?> </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Address Line 1</label>
							<input type="text" class="form-control m-input m-input--square"  name="address1"  id="address1" placeholder="Address Line 1"<?php if (isset($agency->address1) && !empty($agency->address1)){?> value="<?php echo e($agency->address1); ?>" <?php }else{ ?>value="<?php echo e(old('address1')); ?>"<?php } ?>>
                             <span class="error-message">  <?php if($errors->has('address1')): ?>
                       						  <?php echo e($errors->first('address1')); ?>

                       							 <?php endif; ?> </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Address Line 2</label>
							<input type="text" class="form-control m-input m-input--square" name="address2" id="address2" placeholder="Address Line 2"<?php if (isset($agency->address2) && !empty($agency->address2)){?> value="<?php echo e($agency->address2); ?>" <?php }else{ ?>value="<?php echo e(old('address2')); ?>"<?php } ?>>
                             
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Country</label>
							<input type="text" class="form-control m-input m-input--square"  name="country" id="country" placeholder="Country" <?php if (isset($agency->country) && !empty($agency->country)){?> value="<?php echo e($agency->country); ?>" <?php }else{ ?>value="<?php echo e(old('country')); ?>"<?php } ?>>
                             <span class="error-message">  <?php if($errors->has('country')): ?>
                       						  <?php echo e($errors->first('country')); ?>

                       							 <?php endif; ?> </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>City</label>
							<input type="text" class="form-control m-input m-input--square" name="city" id="city" placeholder="City" <?php if (isset($agency->city) && !empty($agency->city)){?> value="<?php echo e($agency->city); ?>" <?php }else{ ?>value="<?php echo e(old('city')); ?>"<?php } ?>>
                               <span class="error-message">  <?php if($errors->has('city')): ?>
                       						  <?php echo e($errors->first('city')); ?>

                       							 <?php endif; ?> </span>
															</div>
														</div>
												   </div>
												    <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Zip / Postal Code</label>
							<input type="text" class="form-control m-input m-input--square"  name="zip" id="zip" placeholder="Zip / Postal Code"  <?php if (isset($agency->pcode) && !empty($agency->pcode)){?> value="<?php echo e($agency->pcode); ?>" <?php }else{ ?>value="<?php echo e(old('zip')); ?>"<?php } ?>>
                             <span class="error-message">  <?php if($errors->has('zip')): ?>
                       						  <?php echo e($errors->first('zip')); ?>

                       							 <?php endif; ?> </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Mobile</label>
							<input type="text" class="form-control m-input m-input--square" name="amobile" id="mobile1"  placeholder="Mobile" <?php if (isset($agency->amobile) && !empty($agency->amobile)){?> value="<?php echo e($agency->amobile); ?>" <?php }else{ ?>value="<?php echo e(old('amobile')); ?>"<?php } ?>>
                            <span class="error-message">  <?php if($errors->has('amobile')): ?>
                       						  <?php echo e($errors->first('amobile')); ?>

                       							 <?php endif; ?> </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                          <label>phone</label>
							<input type="text" class="form-control m-input m-input--square"  name="aphone" id="phone1"  placeholder="phone" <?php if (isset($agency->aphone) && !empty($agency->aphone)){?> value="<?php echo e($agency->aphone); ?>" <?php }else{ ?>value="<?php echo e(old('aphone')); ?>"<?php } ?>>
                              <span class="error-message">  <?php if($errors->has('aphone')): ?>
                       						  <?php echo e($errors->first('aphone')); ?>

                       							 <?php endif; ?> </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Whatsapp</label>
							<input type="text" class="form-control m-input m-input--square"   name="awhatsapp" id="whatsapp1" placeholder="Whatsapp" <?php if (isset($agency->awhatsapp) && !empty($agency->awhatsapp)){?> value="<?php echo e($agency->awhatsapp); ?>" <?php }else{ ?>value="<?php echo e(old('awhatsapp')); ?>"<?php } ?>>
                                <span class="error-message">  <?php if($errors->has('awhatsapp')): ?>
                       						  <?php echo e($errors->first('awhatsapp')); ?>

                       							 <?php endif; ?> </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Skype</label>
							<input type="text" class="form-control m-input m-input--square required"  name="skype" id="skype" placeholder="Skype" <?php if (isset($agency->skype) && !empty($agency->skype)){?> value="<?php echo e($agency->skype); ?>" <?php }else{ ?>value="<?php echo e(old('skype')); ?>"<?php } ?>>
                             <span class="error-message">  <?php if($errors->has('skype')): ?>
                       						  <?php echo e($errors->first('skype')); ?>

                       							 <?php endif; ?> </span>
															</div>
														</div>
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Website</label>
							<input type="text" class="form-control m-input m-input--square"  name="website" placeholder="Website"<?php if (isset($agency->website) && !empty($agency->website)){?> value="<?php echo e($agency->website); ?>" <?php }else{ ?>value="<?php echo e(old('website')); ?>"<?php } ?>>
                               <span class="error-message">  <?php if($errors->has('website')): ?>
                       						  <?php echo e($errors->first('website')); ?>

                       							 <?php endif; ?> </span>
															</div>
														</div>
												   </div>
												   <div class="row">
														<div class="col-md-6">
															<div class="form-group m-form__group">
                                                            <label>Company Registration number</label>
							 <input type="text" class="form-control m-input m-input--square required" name="register_number"  id="register_number"  placeholder="Company Registration number" <?php if (isset($agency->rnumber) && !empty($agency->rnumber)){?> value="<?php echo e($agency->rnumber); ?>" <?php }else{ ?>value="<?php echo e(old('register_number')); ?>"<?php } ?>>
                               <span class="error-message">  <?php if($errors->has('register_number')): ?>
                       						  <?php echo e($errors->first('register_number')); ?>

                       							 <?php endif; ?> </span>
															</div>
														</div>
														
												   </div>
												 
												    <div class="row">
														<div class="col-md-6">
                                                         
									<button type="submit" class="btn btn-primary">Update Manager Details</button>
														</div>
													</div>
											</div>
                                            </form>
											</div>
							</div>
						<!--End::Section-->

						
						<!--End::Section-->
					</div>
				</div>
		
			<!-- end:: Body -->
            <!-- begin::Footer -->
								 <?php if(isset($_GET['id']) && !empty($_GET['id'])){?>           
                                <input type="hidden" id="homeurl" value="<?php echo URL::to("/agency?id=".$_GET['id']);?>"/>
                                <?php } ?>
<?php $__env->stopSection(); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function (){
		
$("#phone").keypress(function (e) {

  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
       }
	   else
	   {
		 $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });
$("#mobile").keypress(function (e) {
  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
		  
                 return false;
       }
	   else
	   {
		 $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });	 
$("#whatsapp").keypress(function (e) {
  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
       }
	   else
	   {
		  $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });
	 
	 //Thana Start
	 
	 $("#zip").keypress(function (e) {
  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
       }
	   else
	   {
		 $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });
	 
	 
	 $("#mobile1").keypress(function (e) {
  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
       }
	   else
	   {
		 $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });
	 
	 
	 	 $("#phone1").keypress(function (e) {
  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
       }
	   else
	   {
		 $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });
	 
	 
	  $("#whatsapp1").keypress(function (e) {
  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
       }
	   else
	   {
		 $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });
	 
	 
	 	  /*$("#skype").keypress(function (e) {
  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
       }
	   else
	   {
		 $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });*/
	 
	 
	 /*
	 	  $("#register_number").keypress(function (e) {
  if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) 
       {
          $("#errmsg").html("Digits Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
       }
	   else
	   {
		 $(this).css({"border-color": "#ebedf2","color":"#575962"});
	   }
     });*/
	 
	 
	 $(".required").each(function() {
        if ($(this).val() === "") {
			e.preventDefault();
            $(this).css('border','1px solid #ff1400');
            counter++;
        }else { $(this).css('border','2px solid #dadde2'); }
    });
	 
	 $('#country').keypress(function (e) {
        var regex = new RegExp("^[a-zA-Z]+$");
        var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
        if (regex.test(str)) {
			$(this).css({"border-color": "#ebedf2","color":"#575962"});
            return true;
        }
        else
        {
        e.preventDefault();
		 $("#errmsg").html("Alphabets Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
        }
		
    });	
	
	
	
	
	$('#address1').keypress(function (e) {
        var regex = new RegExp("^[a-zA-Z]+$");
        var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
        if (regex.test(str)) {
			$(this).css({"border-color": "#ebedf2","color":"#575962"});
            return true;
        }
        else
        {
        e.preventDefault();
		 $("#errmsg").html("Alphabets Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
        }
		
    });	
	
	
	$('#address2').keypress(function (e) {
        var regex = new RegExp("^[a-zA-Z]+$");
        var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
        if (regex.test(str)) {
			$(this).css({"border-color": "#ebedf2","color":"#575962"});
            return true;
        }
        else
        {
        e.preventDefault();
		 $("#errmsg").html("Alphabets Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
        }
		
    });	
	
	$('#city').keypress(function (e) {
        var regex = new RegExp("^[a-zA-Z]+$");
        var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
        if (regex.test(str)) {
			$(this).css({"border-color": "#ebedf2","color":"#575962"});
            return true;
        }
        else
        {
        e.preventDefault();
		 $("#errmsg").html("Alphabets Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
        }
		
    });	
	 
	 
	 	$('#aname').keypress(function (e) {
        var regex = new RegExp("^[a-zA-Z]+$");
        var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
        if (regex.test(str)) {
			$(this).css({"border-color": "#ebedf2","color":"#575962"});
            return true;
        }
        else
        {
        e.preventDefault();
		 $("#errmsg").html("Alphabets Only").show().fadeOut(5000);
          $(this).css({"border": "1px solid red"});
                 return false;
        }
		
    });	
	
	
	
	 	
	 //Thana End	  
});
</script>

<?php if(isset($_GET['id']) && !empty($_GET['id'])){?>
<script>
$(document).ready(function (){


$('.managerdetails').click(function (){
	var url = $('#homeurl').val();
    window.history.pushState('', '', url+'&tab=1');
});

$('.agencyinfo').click(function (){
	var url = $('#homeurl').val();
    window.history.pushState('', '', url+'&tab=2');
});
	
	
});
	


</script>
<?php } ?> 
<style>
#errmsg
{
 color:red;
}

.error-message {
    color: #ff3c41;
    padding: 5px 10px;
    margin-left: 0;
    width: 100%;
}
</style>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>