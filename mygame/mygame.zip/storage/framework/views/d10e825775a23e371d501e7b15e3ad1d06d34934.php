        <?php echo $__env->make('./includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="m-grid__item m-grid__item--fluid m-grid m-grid--ver-desktop m-grid--desktop m-body">		
        <?php echo $__env->make('includes.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
           <?php echo $__env->yieldContent('content'); ?>
		   </div>
        <?php echo $__env->make('./includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>